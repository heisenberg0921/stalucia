
/* ═══════════════════════════════════════════════════════
   TRANSACTION DETAIL VIEW  — openTxDetail(type, id)
   Opens a beautiful read-only sheet; Edit button inside
   opens the editEntry form.
   ═══════════════════════════════════════════════════════ */
var _txdCurrent = { type: null, id: null };

function openTxDetail(type, id) {
  var e = S[type] ? S[type].find(function(x){ return String(x.id)===String(id); }) : null;
  if (!e) return;
  _txdCurrent = { type: type, id: id };

  // ── Hero ──────────────────────────────────────────────
  var isIncome   = type==='income';
  var isExpense  = type==='expense';
  var isTransfer = type==='transfer';
  var isCredit   = type==='credit';
  var isSavings  = type==='savings';

  var cat = e.category || (isIncome?'Salary':isExpense?'Other':isTransfer?'Transfer':isCredit?'Credit':'Savings');
  var iconHtml  = (typeof catIcon==='function') ? catIcon(cat) : '';
  var iconColor = (typeof catColor==='function') ? catColor(cat) : '#60A5FA';
  var iconBgAlpha = iconColor;
  // Soften bg: pick a 15% opacity version
  var iconWrap = document.getElementById('txd-icon-wrap');
  iconWrap.innerHTML = iconHtml;
  iconWrap.style.background = 'color-mix(in srgb,' + iconColor + ' 15%, transparent)';
  iconWrap.style.color = iconColor;
  // Fix SVG strokes
  iconWrap.querySelectorAll('svg').forEach(function(s){
    s.style.width='32px'; s.style.height='32px';
  });

  // Badge
  var badgeMap = { income:'Income', expense:'Expense', transfer:'Transfer', credit:'Credit', savings:'Savings' };
  var badgeColor = isIncome?'var(--green)':isExpense?'var(--red-mid)':isTransfer?'var(--blue-mid)':isCredit?'var(--amber-mid)':'var(--accent)';
  var badgeBg    = isIncome?'var(--green-s)':isExpense?'var(--red-s)':isTransfer?'var(--blue-s)':isCredit?'var(--amber-s)':'var(--accent-s)';
  var badge = document.getElementById('txd-badge');
  badge.textContent = badgeMap[type] || type;
  badge.style.color = badgeColor;
  badge.style.background = badgeBg;
  badge.style.border = '1px solid ' + badgeColor.replace(')', ',0.25)').replace('var(','rgba(').replace(')','');

  // Amount
  var amtEl = document.getElementById('txd-amount');
  var amtSign = isIncome?'+':isExpense?'-':isTransfer?'':'';
  var amtColor= isIncome?'var(--green)':isExpense?'var(--red-mid)':'var(--t1)';
  amtEl.textContent = amtSign + (typeof fmt==='function' ? fmt(e.amt) : e.amt);
  amtEl.style.color = amtColor;

  // Title (source / desc / goal)
  var titleEl = document.getElementById('txd-title');
  var titleText = e.source || e.desc || e.goal || '—';
  titleEl.textContent = titleText;

  // ── Detail rows ────────────────────────────────────────
  var rows = [];

  // Date
  var dateStr = e.date || '—';
  try { dateStr = new Date(e.date + 'T00:00:00').toLocaleDateString(undefined,{weekday:'short',year:'numeric',month:'long',day:'numeric'}); } catch(ex){}
  rows.push({ icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>', label:'Date', value: dateStr });

  // Source / Description / Goal
  if (e.source) rows.push({ icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>', label:'Source', value: e.source });
  if (e.desc)   rows.push({ icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>', label:'Description', value: e.desc });
  if (e.goal)   rows.push({ icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>', label:'Goal', value: e.goal });

  // Category
  if (cat) rows.push({ icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>', label:'Category', value: cat });

  // Account
  if (e.account && typeof accName==='function') rows.push({ icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>', label:'Account', value: accName(e.account) });

  // Transfer: from/to
  if (isTransfer && e.from && e.to && typeof accName==='function') {
    rows.push({ icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M7 16V4m0 0L3 8m4-4l4 4M17 8v12m0 0l4-4m-4 4l-4-4"/></svg>', label:'From → To', value: accName(e.from) + '  →  ' + accName(e.to) });
  }

  // Credit card
  if (isCredit && e.card) rows.push({ icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>', label:'Card', value: e.card + (e.isPaid ? '  ✓ Paid' : '') });
  if (isCredit && e.due) rows.push({ icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>', label:'Due Date', value: e.due });

  // Note
  if (e.note) rows.push({ icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>', label:'Note', value: e.note });

  var detailsEl = document.getElementById('txd-details');
  detailsEl.innerHTML = rows.map(function(r){
    return '<div class="txd-row"><div class="txd-row-icon">'+r.icon+'</div><div class="txd-row-body"><div class="txd-row-label">'+r.label+'</div><div class="txd-row-value">'+r.value+'</div></div></div>';
  }).join('');

  // Show/hide edit button for transfers
  var editBtn = document.getElementById('txd-edit-btn');
  var delBtn  = document.getElementById('txd-delete-btn');
  if (editBtn) editBtn.style.display = isTransfer ? 'none' : 'flex';
  if (delBtn)  delBtn.style.flex = isTransfer ? '1' : '0 0 auto';
  if (delBtn && isTransfer) { delBtn.style.width='100%'; delBtn.style.borderRadius='12px'; }
  else if (delBtn) { delBtn.style.width='44px'; }

  // Open overlay
  var overlay = document.getElementById('txd-overlay');
  overlay.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}

function closeTxDetail() {
  var sheet = document.getElementById('txd-sheet');
  var overlay = document.getElementById('txd-overlay');
  if (sheet) sheet.style.animation = 'txd-slide-up .25s cubic-bezier(.32,.72,0,1) reverse both';
  setTimeout(function(){
    if (overlay) { overlay.style.display='none'; }
    if (sheet) sheet.style.animation = '';
    document.body.style.overflow = '';
  }, 240);
}

function txdEditCurrent() {
  closeTxDetail();
  setTimeout(function(){
    if (_txdCurrent.type && _txdCurrent.id && typeof editEntry==='function') {
      editEntry(_txdCurrent.type, _txdCurrent.id);
    }
  }, 260);
}

function txdDeleteCurrent() {
  closeTxDetail();
  setTimeout(function(){
    if (_txdCurrent.type && _txdCurrent.id && typeof deleteEntry==='function') {
      deleteEntry(_txdCurrent.type, _txdCurrent.id);
    }
  }, 260);
}

// Close on backdrop click
document.getElementById('txd-backdrop').addEventListener('click', closeTxDetail);
// Close on Escape
document.addEventListener('keydown', function(ev){
  if (ev.key==='Escape') {
    var ov=document.getElementById('txd-overlay');
    if(ov && ov.style.display==='flex') closeTxDetail();
  }
});
