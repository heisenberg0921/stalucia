
/* ══════════════════════════════════════════════════════════════════
   FINTRA PRIVACY ENGINE v3 — Scoped per-category masking
   ─────────────────────────────────────────────────────────────────
   State:
     _privacyOn          boolean — master switch
     _pvScopes           object  — per-category enabled flags
   Architecture:
     Each element is tagged with a data-pv-scope attribute during
     initPrivacyMasks(). togglePrivacyMode() / pvToggleScope() call
     _applyPrivacy() which adds/removes body.privacy-mode AND
     adds/removes scope-specific body classes (pv-hide-net_worth etc.)
     CSS only masks elements whose scope class is active.
     MutationObserver re-wraps values re-rendered by Firebase.
   ══════════════════════════════════════════════════════════════════ */

var _privacyOn  = false;
var _pvObserver = null;
var _pvMasked   = new WeakSet();

/* ── SCOPE MAP: selector → scope key ──────────────────────────── */
var PV_SCOPE_MAP = [
  /* Net Worth */
  { scope: 'net_worth',    sel: '.d-hero-val,.d-hs-val,.d-hero-change,.d-hero-rate,.nw-val,.nw-iv,.hero-float-val,.hero-float-aside-val' },
  /* Account Balances */
  { scope: 'balances',     sel: '.acc-bal,.acc-balance,.bank-balance,.kval' },
  /* Transaction amounts — .bill-amt removed (owned by bills scope) */
  { scope: 'transactions', sel: '.ramt,.mob-amt,.ri-float-amt,.fc-amt,.gp,.fina-ctx-val,.icard-value' },
  /* Spending / Budgets — .dbi-amt removed (owned by bills scope) */
  { scope: 'spending',     sel: '.dgroup-val,.dgroup-amt,.d-budget-spent,.d-remain-val,.sc-v,.sub-stat-v' },
  /* Savings / Goals — expanded to cover all goal card values */
  { scope: 'savings',      sel: '.hf-pts,.goal-amt,.goal-saved,.goal-progress-val,.goal-remain,.savings-val' },
  /* Bills — sole owner of .bill-amt and .dbi-amt */
  { scope: 'bills',        sel: '.bill-amt,.dbi-amt' },
];

/* Build a flat selector → scope lookup */
var _elScopeMap = {};
PV_SCOPE_MAP.forEach(function(entry) {
  entry.sel.split(',').forEach(function(s) {
    _elScopeMap[s.trim()] = entry.scope;
  });
});

/* Default scope states — all ON */
var _pvScopes = {
  net_worth:    true,
  balances:     true,
  transactions: true,
  spending:     true,
  savings:      true,
  bills:        true,
};

/* ── Eye SVG ───────────────────────────────────────────────────── */
var _EYE_OPEN  = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
var _EYE_SLASH = '<path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';

/* ── Wrap one element ─────────────────────────────────────────── */
function _wrapEl(el, scope) {
  if (_pvMasked.has(el)) return;
  if (el.querySelector && el.querySelector('.pv-real')) return;
  var innerHtml = el.innerHTML;
  el.classList.add('pv-el');
  el.dataset.pvScope = scope;
  var cs = window.getComputedStyle(el);
  if (cs.display === 'block' || cs.display === 'flex' || cs.display === 'grid') {
    el.classList.add('pv-block');
  }
  el.innerHTML =
    '<span class="pv-real" aria-hidden="false">' + innerHtml + '</span>' +
    '<span class="pv-mask" aria-hidden="true">••••••••</span>';
  _pvMasked.add(el);
}

/* ── Inject CSS for each scope body class ────────────────────── */
function _injectScopeCSS() {
  var id = 'pv-scope-style';
  if (document.getElementById(id)) return;
  var style = document.createElement('style');
  style.id = id;
  var rules = '';
  Object.keys(_pvScopes).forEach(function(scope) {
    rules +=
      'body.privacy-mode.pv-hide-' + scope + ' .pv-el[data-pv-scope="' + scope + '"] > .pv-real { opacity:0!important; }\n' +
      'body.privacy-mode.pv-hide-' + scope + ' .pv-el[data-pv-scope="' + scope + '"] > .pv-mask { opacity:1!important; }\n';
  });
  style.textContent = rules;
  document.head.appendChild(style);
}

/* ── Scan & wrap all matching elements ───────────────────────── */
function initPrivacyMasks() {
  _injectScopeCSS();
  PV_SCOPE_MAP.forEach(function(entry) {
    document.querySelectorAll(entry.sel).forEach(function(el) {
      _wrapEl(el, entry.scope);
    });
  });
}

/* ── MutationObserver: re-wrap when Firebase rewrites a value ── */
function _startObserver() {
  if (_pvObserver) return;
  var allSel = PV_SCOPE_MAP.map(function(e){ return e.sel; }).join(',');
  _pvObserver = new MutationObserver(function(mutations) {
    mutations.forEach(function(m) {
      var el = m.target.nodeType === 3 ? m.target.parentElement : m.target;
      if (!el) return;
      if (el.classList && el.classList.contains('pv-el') && !el.querySelector('.pv-real')) {
        _pvMasked.delete(el);
        var scope = el.dataset.pvScope || 'net_worth';
        _wrapEl(el, scope);
      } else if (el.matches) {
        try {
          if (el.matches(allSel) && !el.classList.contains('pv-el')) {
            var matched = PV_SCOPE_MAP.find(function(e){ return el.matches(e.sel); });
            if (matched) _wrapEl(el, matched.scope);
          }
        } catch(e) {}
      }
    });
  });
  _pvObserver.observe(document.body, { childList:true, subtree:true, characterData:true });
}

/* ── Apply body classes for active scopes ─────────────────────── */
function _applyPrivacy(on) {
  document.body.classList.toggle('privacy-mode', on);
  Object.keys(_pvScopes).forEach(function(scope) {
    document.body.classList.toggle('pv-hide-' + scope, on && _pvScopes[scope]);
  });
  _syncEyeIcons(on);
  _syncSettingsUI();
}

/* ── Sync eye icons ───────────────────────────────────────────── */
function _syncEyeIcons(hidden) {
  var path = hidden ? _EYE_SLASH : _EYE_OPEN;
  var hIcon = document.getElementById('privacy-eye-icon');
  var hBtn  = document.getElementById('privacy-toggle-btn');
  if (hIcon) hIcon.innerHTML = path;
  if (hBtn)  hBtn.classList.toggle('active', hidden);
  var heroIcon = document.getElementById('hero-eye-icon');
  if (heroIcon) heroIcon.innerHTML = path;
}
function _updatePrivacyIcon(h) { _syncEyeIcons(h); } /* compat */

/* ── PUBLIC: master toggle (hero card + any caller) ──────────── */
function togglePrivacyMode() {
  _privacyOn = !_privacyOn;
  _applyPrivacy(_privacyOn);
  _saveState();
  if (typeof toast === 'function')
    toast(_privacyOn ? 'Values hidden' : 'Values visible', 'success');
}

/* ══ PRIVACY SETTINGS SHEET ════════════════════════════════════ */
function openPvSettings() {
  /* Close sidebar if open */
  var ham = document.getElementById('ham-btn');
  if (ham && ham.classList.contains('open')) ham.click();
  var sheet = document.getElementById('pv-settings-sheet');
  if (sheet) sheet.classList.add('open');
  _syncSettingsUI();
}
function closePvSettings() {
  var sheet = document.getElementById('pv-settings-sheet');
  if (sheet) sheet.classList.remove('open');
}

/* Toggle master from within the settings sheet */
function pvToggleMaster() {
  _privacyOn = !_privacyOn;
  _applyPrivacy(_privacyOn);
  _saveState();
  /* Mirror the same toast feedback as the hero card toggle */
  if (typeof toast === 'function')
    toast(_privacyOn ? 'Values hidden' : 'Values visible', 'success');
}

/* Toggle individual scope */
function pvToggleScope(scope) {
  _pvScopes[scope] = !_pvScopes[scope];
  /* Re-apply body classes */
  document.body.classList.toggle('pv-hide-' + scope, _privacyOn && _pvScopes[scope]);
  _syncSettingsUI();
  _saveState();
}

/* Sync settings sheet UI to current state */
function _syncSettingsUI() {
  /* Master toggle */
  var mt = document.getElementById('pvs-master-toggle');
  if (mt) mt.classList.toggle('on', _privacyOn);
  var ms = document.getElementById('pvs-master-sub');
  if (ms) ms.textContent = _privacyOn ? 'Privacy mode is ON' : 'Tap to hide all amounts';
  var me = document.getElementById('pvs-master-eye');
  if (me) me.innerHTML = _privacyOn ? _EYE_SLASH : _EYE_OPEN;
  /* Rows wrap disabled when master off */
  var wrap = document.getElementById('pvs-rows-wrap');
  if (wrap) wrap.classList.toggle('disabled', !_privacyOn);
  /* Individual toggles */
  Object.keys(_pvScopes).forEach(function(scope) {
    var tog = document.getElementById('pvs-scope-' + scope);
    if (tog) tog.classList.toggle('on', _pvScopes[scope]);
  });
  /* Profile panel badge + sub-label */
  var badge = document.getElementById('pvs-sidebar-badge');
  if (badge) badge.style.display = _privacyOn ? 'inline-block' : 'none';
  var profileSub = document.getElementById('pvs-profile-sub');
  if (profileSub) profileSub.textContent = _privacyOn ? 'Privacy is ON' : 'Choose what to hide';
}

/* ── Persist to localStorage ──────────────────────────────────── */
function _saveState() {
  localStorage.setItem('fintra_privacy_mode',   _privacyOn ? '1' : '0');
  localStorage.setItem('fintra_privacy_scopes', JSON.stringify(_pvScopes));
}

/* ── Restore persisted state ──────────────────────────────────── */
(function _restoreState() {
  try {
    var saved = localStorage.getItem('fintra_privacy_scopes');
    if (saved) {
      var parsed = JSON.parse(saved);
      Object.keys(parsed).forEach(function(k) {
        if (_pvScopes.hasOwnProperty(k)) _pvScopes[k] = !!parsed[k];
      });
    }
  } catch(e) {}
  if (localStorage.getItem('fintra_privacy_mode') === '1') {
    _privacyOn = true;
    _applyPrivacy(true);
  }
})();

/* ── Init ─────────────────────────────────────────────────────── */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', function() {
    initPrivacyMasks();
    _startObserver();
  });
} else {
  initPrivacyMasks();
  _startObserver();
}
/* NOTE: Removed redundant setTimeout fallback inits (1400ms, 3500ms).
   The MutationObserver in _startObserver() handles Firebase-rendered
   elements reactively. If elements are still missed, investigate the
   observer's subtree/characterData config rather than adding timeouts. */

/* ══ AUTO-HIDE on background ══════════════════════════════════ */
function dismissPrivacyBanner() {
  var banner = document.getElementById('privacy-banner');
  if (banner) banner.classList.remove('show');
}
document.addEventListener('visibilitychange', function() {
  var banner = document.getElementById('privacy-banner');
  if (!banner) return;
  if (document.hidden) {
    /* Only show the overlay when privacy mode is actually enabled */
    if (_privacyOn) { banner.classList.add('show'); }
  } else {
    /* Auto-dismiss when user returns to the app — no manual Unlock needed
       unless you intentionally want to keep the gate; remove this block if so */
    banner.classList.remove('show');
  }
});
window.addEventListener('pagehide', function() {
  var banner = document.getElementById('privacy-banner');
  /* Guard: show banner on page-hide only when privacy mode is on */
  if (_privacyOn && banner) banner.classList.add('show');
});
