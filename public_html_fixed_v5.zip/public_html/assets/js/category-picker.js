
(function(){
  var CATS={
    expense:['Food','Transport','Utilities','Health','Shopping','Entertainment','Rent','Education','Subscription','Other'],
    income:['Salary','Freelance','Business','Investment','Gift','Bonus','Other'],
    transfer:[],
    credit:['Shopping','Food','Travel','Health','Utilities','Subscription','Other']
  };
  var SAVE_LABELS={expense:'Log Expense',income:'Add Income',transfer:'Transfer Now',credit:'Charge Card'};
  var AMOUNT_HINTS={expense:'Amount Spent',income:'Amount Received',transfer:'Transfer Amount',credit:'Charge Amount'};
  var _type='expense',_selectedCat='',_selectedAccId='',_selectedAccToId='';
  function $(id){return document.getElementById(id);}
  function todayStr(){var d=new Date(),m=d.getMonth()+1,dd=d.getDate();return d.getFullYear()+'-'+(m<10?'0':'')+m+'-'+(dd<10?'0':'')+dd;} // local tz, not UTC

  function currentAmount(){
    var inp=$('csh-amount-val');
    var n=inp?parseFloat(inp.value):0;
    return isNaN(n)||n<0?0:n;
  }

  function renderAmt(){
    var sb=$('csh-save-btn');
    if(sb) sb.disabled=currentAmount()<=0;
  }

  /* ── Account icon HTML — uses logo if set, else type SVG ── */
  function accCardIcoHtml(a){
    if(a.logo) return '<img src="'+_esc(a.logo)+'" alt="'+_esc(a.name)+'">';
    var ACC_TYPE_ICON=window.ACC_TYPE_ICON||{};
    var typeKey=(a.type||'').toLowerCase();
    var info=(a.isCC?ACC_TYPE_ICON['credit card']:ACC_TYPE_ICON[typeKey])||ACC_TYPE_ICON['default'];
    if(!info) return '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><rect x="1.5" y="4" width="13" height="9" rx="1.5"/><path d="M5 4V3a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 11 3v1"/><line x1="1.5" y1="9" x2="14.5" y2="9"/></svg>';
    return info.svg.replace('stroke="currentColor"','stroke="'+info.stroke+'"');
  }

  /* ── Format balance for mini account cards ── */
  function fmtBal(a){
    if(a.isCC){
      var avail=Math.max(0,(a.creditLimit||0)-(a.usedCredit||0));
      var n=window.fmt?window.fmt(avail):('₱'+avail.toFixed(2));
      return n+' avail';
    }
    var v=+(a.balance||0);
    return window.fmt?window.fmt(v):('₱'+v.toFixed(2));
  }

  /* ── Build a set of account cards into a container ── */
  function buildAccCards(container,accs,selectedId,onSelect){
    if(!container)return;
    container.innerHTML=accs.map(function(a){
      var sel=a.id===selectedId?' selected':'';
      return '<div class="csh-acc-card'+sel+'" data-id="'+_esc(a.id)+'">'
        +'<div class="csh-acc-card-ico">'+accCardIcoHtml(a)+'</div>'
        +'<div class="csh-acc-card-name">'+_esc(a.name)+'</div>'
        +'<div class="csh-acc-card-bal">'+fmtBal(a)+'</div>'
        +'</div>';
    }).join('');
    container.querySelectorAll('.csh-acc-card').forEach(function(card){
      card.addEventListener('click',function(){
        container.querySelectorAll('.csh-acc-card').forEach(function(c){c.classList.remove('selected');});
        card.classList.add('selected');
        onSelect(card.dataset.id);
      });
    });
  }

  function fillSheetSelects(){
    var S=window.S; if(!S||!S.accounts)return;
    var accs=S.accounts.filter(function(a){return!a.archived;});
    var ccOnly=_type==='credit';
    /* STRICT: credit type shows ONLY credit card accounts — no fallback to all */
    var fromList=ccOnly
      ? accs.filter(function(a){return a.isCC||(a.type||'').toLowerCase().indexOf('credit')>-1;})
      : accs.filter(function(a){return !a.isCC;});  /* non-credit types exclude CC accounts */
    /* legacy selects (hidden, kept for doSave) */
    var sf=$('csh-acc-from'); if(sf){sf.innerHTML=fromList.map(function(a){return'<option value="'+a.id+'">'+_esc(a.name)+'</option>';}).join('');}
    var st=$('csh-acc-to');   if(st){st.innerHTML=accs.map(function(a){return'<option value="'+a.id+'">'+_esc(a.name)+'</option>';}).join('');}
    /* default selection */
    if(!_selectedAccId&&fromList.length){_selectedAccId=fromList[0].id; if(sf)sf.value=_selectedAccId;}
    if(!_selectedAccToId&&accs.length){_selectedAccToId=accs[0].id; if(st)st.value=_selectedAccToId;}
    /* render cards */
    buildAccCards($('csh-acc-cards'),fromList,_selectedAccId,function(id){
      _selectedAccId=id;
      var sf=$('csh-acc-from'); if(sf)sf.value=id;
      if(_type==='transfer') autoDetectTransferFee();
    });
    buildAccCards($('csh-acc-to-cards'),accs,_selectedAccToId,function(id){
      _selectedAccToId=id;
      var st=$('csh-acc-to'); if(st)st.value=id;
      if(_type==='transfer') autoDetectTransferFee();
    });
  }

  /* ── Auto-detect transfer fee based on from/to account banks ── */
  function autoDetectTransferFee(){
    var S=window.S; if(!S||!S.accounts)return;
    var accs=S.accounts;
    var fromAcc=null,toAcc=null;
    for(var i=0;i<accs.length;i++){
      if(String(accs[i].id)===String(_selectedAccId)) fromAcc=accs[i];
      if(String(accs[i].id)===String(_selectedAccToId)) toAcc=accs[i];
    }
    if(!fromAcc||!toAcc)return;
    var fromBank=(fromAcc.provider_id||fromAcc.provider_name||fromAcc.name||'').toLowerCase().trim();
    var toBank=(toAcc.provider_id||toAcc.provider_name||toAcc.name||'').toLowerCase().trim();
    var _normBank=function(s){return s.replace(/\b(savings|checking|wallet|account|credit|debit|card|e-wallet|ewallet)\b/gi,'').replace(/\s+/g,' ').trim();};
    var fromKey=(fromAcc.provider_id&&toAcc.provider_id)?fromAcc.provider_id:_normBank(fromBank);
    var toKey=(fromAcc.provider_id&&toAcc.provider_id)?toAcc.provider_id:_normBank(toBank);
    var isSameBank=(fromKey&&toKey&&fromKey===toKey);
    var _isZero=function(s){return/(gcash|maya|paymaya|coins\.ph|grabpay)/i.test(s);};
    var fromIsZero=_isZero(fromBank),toIsZero=_isZero(toBank);
    var suggestFee=0;
    if(!isSameBank&&!fromIsZero&&!toIsZero){ suggestFee=15; }
    var fi=document.getElementById('csh-fee-input');
    if(fi){ fi.value=suggestFee>0?suggestFee:''; }
    var fh=document.getElementById('csh-fee-hint');
    if(fh){
      if(isSameBank){
        fh.innerHTML='🏦 Same bank transfer — no fee charged.';
        fh.classList.add('show');
      } else if(fromIsZero||toIsZero){
        fh.innerHTML='📲 GCash/Maya transfers are free.';
        fh.classList.add('show');
      } else {
        fh.innerHTML='🏦 Different bank detected — <strong>₱15 InstaPay fee</strong> suggested. Adjust if needed.';
        fh.classList.add('show');
      }
    }
  }

  function switchType(t){
    /* Guard: block credit type if no credit card accounts exist */
    if(t==='credit'){
      var _S=window.S;
      var _ccAccs=_S&&_S.accounts?_S.accounts.filter(function(a){return !a.archived&&(a.isCC||(a.type||'').toLowerCase().indexOf('credit')>-1);}):[];
      if(!_ccAccs.length){
        if(window.toast)toast('⚠ No credit card account found. Add a Credit Card account first in Accounts.','error');
        return;
      }
    }
    _type=t; _selectedCat='';
    /* icon cards */
    document.querySelectorAll('.csh-type-card').forEach(function(c){c.className='csh-type-card';});
    var ac=document.querySelector('.csh-type-card[data-type="'+t+'"]');
    if(ac) ac.classList.add('active-'+t);
    /* amount */
    var av=$('csh-amount-val'); if(av) av.className='csh-amount-val type-'+t;
    var aw=$('csh-amount-wrap'); if(aw) aw.className='csh-amount-wrap type-'+t;
    var ah=$('csh-amount-hint'); if(ah) ah.textContent=AMOUNT_HINTS[t]||'Amount';
    /* save btn */
    var sb=$('csh-save-btn');
    if(sb){sb.className='csh-save-btn type-'+t;sb.textContent=SAVE_LABELS[t]||t;sb.disabled=currentAmount()<=0;}
    /* account section label */
    var al=$('csh-acc-section-lbl');
    if(al) al.textContent=t==='credit'?'Credit Card':t==='transfer'?'From Account':'Account';
    /* to account section (transfer only) */
    var tw=$('csh-acc-to-wrap'); if(tw) tw.classList.toggle('show',t==='transfer');
    /* fee section (transfer only) */
    var fw=$('csh-fee-wrap'); if(fw) fw.classList.toggle('show',t==='transfer');
    if(t!=='transfer'){var fi=$('csh-fee-input');if(fi)fi.value='';var fh=$('csh-fee-hint');if(fh){fh.classList.remove('show');fh.innerHTML='';}}
    renderCats(); renderRecents(); fillSheetSelects();
    if(t==='transfer') setTimeout(autoDetectTransferFee,50);
  }

  function renderCats(){
    var cs=$('csh-cat-section'),c=$('csh-cats'); if(!c)return;
    var list=CATS[_type]||[];
    if(!list.length){if(cs)cs.style.display='none';return;}
    if(cs)cs.style.display='';
    c.innerHTML=list.map(function(cat){
      var isSel=(_selectedCat===cat);
      var icoHtml='';
      if(typeof catIcon==='function'&&typeof catBg==='function'){
        var bg=isSel?catBg(cat):'transparent';
        var ico=catIcon(cat).replace(/width="24" height="24"/g,'width="14" height="14"').replace(/stroke-width="1\.6"/g,'stroke-width="1.8"');
        icoHtml='<span class="csh-cat-ico" style="background:'+bg+'">'+ico+'</span>';
      }
      var selCls=isSel?' sel-'+_type:'';
      return '<button class="csh-cat'+selCls+'" data-cat="'+cat+'">'+icoHtml+'<span class="csh-cat-lbl">'+cat+'</span></button>';
    }).join('');
    c.querySelectorAll('.csh-cat').forEach(function(b){
      b.addEventListener('click',function(){
        _selectedCat=b.dataset.cat===_selectedCat?'':b.dataset.cat; renderCats();
      });
    });
  }

  function _esc(s){var d=document.createElement('div');d.textContent=String(s||'');return d.innerHTML;}

  function renderRecents(){
    var wrap=$('csh-recent-wrap'),row=$('csh-recent-row'); if(!row||!wrap)return;
    var S=window.S; if(!S){wrap.style.display='none';return;}
    var list=[];
    if(_type==='expense'&&S.expense) list=S.expense.slice(-20).reverse();
    else if(_type==='income'&&S.income) list=S.income.slice(-20).reverse();
    var seen={},chips=[];
    (list||[]).forEach(function(e){var k=(e.desc||e.src||e.note||'').toLowerCase().trim();if(!k||seen[k])return;seen[k]=1;chips.push(e);});
    chips=chips.slice(0,5);
    if(!chips.length){wrap.style.display='none';return;}
    wrap.style.display='';
    row.innerHTML=chips.map(function(e,i){
      var lbl=e.desc||e.src||e.note||'';
      return '<div class="csh-recent-chip" data-i="'+i+'"><strong>'+_esc(lbl)+'</strong>'+(e.acc?'<span>'+_esc(e.acc)+'</span>':'')+'</div>';
    }).join('');
    row.querySelectorAll('.csh-recent-chip').forEach(function(chip,idx){
      chip.addEventListener('click',function(){
        var e=chips[idx]; if(!e)return;
        var ai=$('csh-amount-val'); if(ai){ai.value=e.amt||e.amount||'';renderAmt();}
        var ni=$('csh-note'); if(ni)ni.value=e.desc||e.src||e.note||'';
        if(e.cat){_selectedCat=e.cat;renderCats();}
      });
    });
  }

  var _cshSaving=false; // FAMILY D FIX: sheet stays clickable ~240ms while closing — a double-tap duplicated the save
  function doSave(){
    if(_cshSaving)return;
    var amt=currentAmount();
    if(amt<=0){if(window.toast)toast('Enter an amount','warning');return;}
    // FinanceCore (Bug 3): business-layer validation — finite, ≤ max, ≤ 2 decimals.
    if(window.FinanceCore&&window.FinanceCore.parseAmount){
      var _amtChk=window.FinanceCore.parseAmount(amt);
      if(!_amtChk.ok){if(window.toast)toast(_amtChk.error,'error');return;}
      amt=_amtChk.value;
    } else if(!isFinite(amt)||amt>1e12){
      if(window.toast)toast('Amount seems too large. Please check.','error');return;
    }
    var note=($('csh-note')||{}).value||'';
    var date=($('csh-date')||{}).value||todayStr();
    var accId=_selectedAccId||($('csh-acc-from')||{}).value||'';
    var acc2Id=_selectedAccToId||($('csh-acc-to')||{}).value||'';
    var S=window.S; if(!S){if(window.toast)toast('App not ready','warning');return;}
    var newId=function(){return Date.now()+Math.floor(Math.random()*1000);};
    var fa=window.findAcc;
    if(_type==='expense'){
      // Same product rule as the full form: an expense may exceed the account
      // balance, but only after explicit confirmation — never silently.
      var _expAcc=(accId&&fa)?fa(accId):null;
      var _commitExpense=function(){
        _cshSaving=true;
        S.expense=S.expense||[];
        S.expense.push({id:newId(),date:date,desc:note,category:_selectedCat||'Other',amt:amt,account:accId});
        if(_expAcc)_expAcc.balance=+(_expAcc.balance-amt).toFixed(2);
        _finalizeSave();
      };
      if(_expAcc&&_expAcc.balance<amt){
        var _fmtC=window.fmt||function(v){return'₱'+Number(v).toFixed(2);};
        var _ovMsg='⚠ This expense ('+_fmtC(amt)+') exceeds your '+_esc(_expAcc.name)+' balance ('+_fmtC(_expAcc.balance)+'). Log anyway?';
        if(typeof window.confirmModal==='function'){window.confirmModal(_ovMsg,_commitExpense);return;}
        if(!window.confirm(_ovMsg.replace(/<[^>]+>/g,'')))return;
      }
      _commitExpense();
      return;
    } else if(_type==='income'){
      _cshSaving=true;
      S.income=S.income||[];
      S.income.push({id:newId(),date:date,source:note,category:_selectedCat||'Other',amt:amt,account:accId});
      if(accId&&fa){var a=fa(accId);if(a)a.balance=+(a.balance+amt).toFixed(2);}
    } else if(_type==='transfer'){
      S.transfer=S.transfer||[];
      // Read fee from sheet
      var _trFeeEl=$('csh-fee-input');
      var _trFee=_trFeeEl?Math.max(0,parseFloat(_trFeeEl.value)||0):0;
      var _trTotal=+(amt+_trFee).toFixed(2);
      // Guard: accounts required
      if(!accId){if(window.toast)toast('Select the account to transfer FROM.','error');return;}
      if(!acc2Id){if(window.toast)toast('Select the account to transfer TO.','error');return;}
      // Guard: no self-transfer
      if(String(accId)===String(acc2Id)){if(window.toast)toast('From and To accounts must be different.','error');return;}
      // Guard: max cap (transfers keep the stricter pre-existing 1e9 product cap)
      if(amt>1000000000){if(window.toast)toast('Transfer amount exceeds maximum allowed (₱1,000,000,000).','error');return;}
      // Guard: sufficient balance (amount + fee) — search S.accounts directly
      var _trFromAcc=null;
      var _accs=S.accounts||[];
      for(var _ti=0;_ti<_accs.length;_ti++){if(String(_accs[_ti].id)===String(accId)){_trFromAcc=_accs[_ti];break;}}
      if(!_trFromAcc&&window.findAcc){_trFromAcc=window.findAcc(accId);}
      // T8/T13 guard: source must exist in authoritative state (not just the UI)
      if(!_trFromAcc){if(window.toast)toast('Source account not found.','error');return;}
      var _trAvail=Number(_trFromAcc.balance)||0;
      var _trFmt=window.fmt||function(v){return'₱'+Number(v).toFixed(2);};
      if(_trAvail<_trTotal){
        var _trName=_trFromAcc.name||'source account';
        var _needMsg=_trFee>0?' ('+_trFmt(amt)+' + '+_trFmt(_trFee)+' fee)':'';
        if(window.toast)toast('⚠ Insufficient balance in '+_trName+'. Available: '+_trFmt(_trAvail)+' — Need: '+_trFmt(_trTotal)+_needMsg+'.','error');
        return;
      }
      _cshSaving=true;
      // Commit: push transfer entry
      var _trEntry={id:newId(),date:date,note:note,amt:amt,from:accId,to:acc2Id};
      if(_trFee>0){_trEntry.fee=_trFee;}
      S.transfer.push(_trEntry);
      // Deduct total (amount + fee) from source; credit only amount to destination
      if(_trFromAcc){_trFromAcc.balance=+(_trAvail-_trTotal).toFixed(2);}
      var _trToAcc=null;
      for(var _ti2=0;_ti2<_accs.length;_ti2++){if(String(_accs[_ti2].id)===String(acc2Id)){_trToAcc=_accs[_ti2];break;}}
      if(!_trToAcc&&window.findAcc){_trToAcc=window.findAcc(acc2Id);}
      if(_trToAcc){_trToAcc.balance=+(Number(_trToAcc.balance||0)+amt).toFixed(2);}
      // Log fee as a separate expense entry so it appears in expense history
      if(_trFee>0&&_trFromAcc){
        S.expense=S.expense||[];
        var _toName=_trToAcc?_trToAcc.name:acc2Id;
        S.expense.push({id:newId(),date:date,desc:'Transfer fee ('+_trFromAcc.name+' → '+_toName+')',category:'Other',account:accId,note:'Fee for transfer of '+_trFmt(amt),amt:_trFee});
      }
    } else if(_type==='credit'){
      S.credit=S.credit||[];
      // Guard: must have a credit card account selected
      if(!accId){if(window.toast)toast('Select a credit card to charge.','error');return;}
      var _ccAcc=null;
      var _allAccs=S.accounts||[];
      for(var _ci=0;_ci<_allAccs.length;_ci++){if(String(_allAccs[_ci].id)===String(accId)){_ccAcc=_allAccs[_ci];break;}}
      // FIX: was `!_ccAcc|(...)` — bitwise OR evaluated the right side eagerly and
      // crashed with a TypeError when the account was missing (save silently died).
      if(!_ccAcc||(!_ccAcc.isCC&&(_ccAcc.type||'').toLowerCase().indexOf('credit')===-1)){
        if(window.toast)toast('⚠ Selected account is not a credit card. Add a Credit Card account in Accounts first.','error');return;
      }
      // FIX: enforce the credit limit — same rule as the full form's Charge path.
      var _ccAvail=Math.max(0,(_ccAcc.creditLimit||0)-(_ccAcc.usedCredit||0));
      if((_ccAcc.creditLimit||0)>0&&amt>_ccAvail){
        var _fmtCC=window.fmt||function(v){return'₱'+Number(v).toFixed(2);};
        if(window.toast)toast('⚠ Over credit limit! Available: '+_fmtCC(_ccAvail),'error');return;
      }
      _cshSaving=true;
      // FIX: record schema now matches the full form (card = name, cardId = id,
      // category not cat) so deleteEntry/editEntry correctly reverse usedCredit
      // and category stats/rendering pick the entry up.
      S.credit.push({id:newId(),date:date,desc:note,card:_ccAcc.name,cardId:_ccAcc.id,category:_selectedCat||'Other',amt:amt,type:'Charge'});
      _ccAcc.usedCredit=+(((_ccAcc.usedCredit||0)+amt)).toFixed(2);
    }
    _finalizeSave();
  }

  function _finalizeSave(){
    if(window.save)save();
    if(window._rebuildAccMap)_rebuildAccMap();
    if(window.fillSelects)fillSelects();
    if(window.updateProfileStats)updateProfileStats();
    try{
      var panel=(typeof PANELS!=='undefined'&&typeof _currentPanelIndex!=='undefined')?PANELS[_currentPanelIndex]:null;
      if(panel==='dashboard'){if(window.renderDash)renderDash();if(window.updateDashHero)updateDashHero();}
      if(panel==='accounts'&&window.renderAccounts)renderAccounts();
      if((panel==='expense'||panel==='income')&&window.renderStat)renderStat(panel);
    }catch(e){}
    closeSheet(); if(window.toast)toast('Saved ✓','success');
  }

  function openSheet(startType){
    _type=startType||'expense'; _selectedCat='';
    _cshSaving=false; // re-arm the double-submit guard for the new session
    var de=$('csh-date'); if(de)de.value=todayStr();
    var ne=$('csh-note'); if(ne)ne.value='';
    var ai=$('csh-amount-val'); if(ai)ai.value='';
    var ov=$('calc-sheet-overlay'); if(ov)ov.classList.add('show');
    var sh=$('calc-sheet'); if(sh){sh.style.transform='';sh.style.opacity='';sh.style.transition='';}
    switchType(_type);
    if(window.ftHaptic)ftHaptic('light');
  }

  function closeSheet(){
    var ov=$('calc-sheet-overlay'); if(!ov)return;
    var sh=$('calc-sheet');
    if(sh){sh.style.transition='transform 0.26s cubic-bezier(0.4,0,1,1),opacity 0.2s ease';sh.style.transform='translateY(48px)';sh.style.opacity='0';}
    setTimeout(function(){ov.classList.remove('show');if(sh){sh.style.transform='';sh.style.opacity='';sh.style.transition='';}},240);
  }

  // Amount input → update save btn
  var amtInp=$('csh-amount-val'); if(amtInp) amtInp.addEventListener('input',renderAmt);

  // Icon card clicks
  document.querySelectorAll('.csh-type-card').forEach(function(card){
    card.addEventListener('click',function(){if(window.ftHaptic)ftHaptic('light');switchType(card.dataset.type);});
  });

  var sb=$('csh-save-btn'); if(sb)sb.addEventListener('click',doSave);
  var cb=$('csh-close-btn'); if(cb)cb.addEventListener('click',closeSheet);
  var ov=$('calc-sheet-overlay');
  if(ov)ov.addEventListener('click',function(e){if(e.target===ov)closeSheet();});

  window.addEventListener('load',function(){
    var orig=window.logForm;
    window.logForm=function(type){
      if(type==='savings'){if(orig)orig(type);return;}
      openSheet(type);
    };
    window._calcSheetOpen=openSheet;
    window._calcSheetClose=closeSheet;
  });
})();
