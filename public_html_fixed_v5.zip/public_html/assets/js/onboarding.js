
// ══ ONBOARDING 2026 — Interactive Fullscreen Flow ══════════════════
var _obStep = 0;
var _obData = { name:'', age:'', gender:'', avatarSrc:'', storage: window._localMode ? 'local' : 'cloud' };
var _OB_TOTAL = 7;
var _obFinaTyping = false;
var _obFinaTypingTimer = null;

function _obProgress() {
  var bar = document.getElementById('ob-progress');
  if (bar) bar.style.width = ((_obStep + 1) / _OB_TOTAL * 100) + '%';
}

function _obDots() {
  var wrap = document.getElementById('ob-dots-wrap');
  if (!wrap) return;
  var html = '';
  for (var i = 0; i < _OB_TOTAL; i++) {
    html += '<div class="ob-dot' + (i === _obStep ? ' active' : '') + '"></div>';
  }
  wrap.innerHTML = html;
}

/* Fina mascot — the real branded mark (finaMark), same one used in the
   chat header and FAB elsewhere in the app, not a generic robot emoji. */
function _obFinaHtml(small) {
  var sz = small ? 80 : 110;
  return '<div class="ob-fina-mascot" style="width:' + sz + 'px;height:' + sz + 'px">'
    + '<div class="ob-fina-mascot-ring"></div>'
    + '<div class="ob-fina-mascot-inner">'
    + '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;height:100%;animation:ob-fina-float 3s ease-in-out infinite">'
    + (typeof finaMark === 'function' ? finaMark({size: small ? 46 : 64, state: 'idle'}) : '<div style="font-size:' + (small?30:44) + 'px;line-height:1">🤖</div>')
    + '</div>'
    + '</div>'
    + '</div>';
}

/* Animated typing then reveal message */
function _obFinaSpeak(bubble, message, delay) {
  delay = delay || 0;
  var typingHtml = '<span class="ob-fina-typing"><span></span><span></span><span></span></span>';
  setTimeout(function() {
    if (bubble) bubble.innerHTML = typingHtml;
    setTimeout(function() {
      if (bubble) bubble.innerHTML = message;
    }, 900);
  }, delay);
}

function _obRender() {
  _obProgress();
  _obDots();
  var content = document.getElementById('ob-content');
  if (!content) return;

  // Animate out first if not first render
  content.style.animation = 'none';
  content.offsetHeight; // reflow
  content.style.animation = '';

  // ── Step 0: Welcome — Fina mascot speaks ─────────────────────
  if (_obStep === 0) {
    var bubbleId = 'ob-fina-bubble-0';
    content.innerHTML =
      '<div class="ob-step">'
      + _obFinaHtml(false)
      + '<div class="ob-fina-bubble" id="' + bubbleId + '">'
      + '<span class="ob-fina-typing"><span></span><span></span><span></span></span>'
      + '</div>'
      + '<div class="ob-input-wrap">'
      + '<label class="ob-input-label">Your first name</label>'
      + '<input id="ob-name-input" class="ob-input" type="text" placeholder="e.g. Felix" autocomplete="given-name" maxlength="40"'
      + ' data-oninput="_obNameInput" data-arg-this="1"'
      + ' data-onkeydown="_enterKeySend" data-onkeydown-a0="__EVENT__" data-onkeydown-a1="_obValidateStep0"'
      + ' value="' + (_obData.name||'') + '">'
      + '</div>'
      + '<button class="ob-btn" data-onclick="_obValidateStep0">Continue →</button>'
      + '</div>';
    setTimeout(function(){
      var bubble = document.getElementById(bubbleId);
      if (bubble) bubble.innerHTML = 'Hey! 👋 Welcome to <strong style="color:#4F8EF7">Fintra</strong> — your personal finance command centre.<br><br>I\'m <strong style="color:#4F8EF7">Fina</strong>, your AI money coach. Let\'s get you set up — it only takes a minute!';
    }, 900);
    setTimeout(function(){ var el=document.getElementById('ob-name-input'); if(el) el.focus(); }, 120);
  }

  // ── Step 1: Age (chip selector) ───────────────────────────────
  else if (_obStep === 1) {
    var name = _obData.name || 'there';
    var ageGroups = ['Under 18','18 – 24','25 – 34','35 – 44','45 – 54','55+'];
    var chipsHtml = ageGroups.map(function(g) {
      return '<button class="ob-chip' + (_obData.age === g ? ' active' : '') + '" data-onclick="_obPickAge" data-a0="' + esc(g) + '">' + g + '</button>';
    }).join('');
    content.innerHTML =
      '<div class="ob-step">'
      + '<div class="ob-hero-icon"><div class="ob-hero-icon-inner">🎂</div></div>'
      + '<h1 class="ob-headline">How old are you,<br><span>' + name + '</span>?</h1>'
      + '<p class="ob-sub">Fintra tailors financial tips based on your life stage.</p>'
      + '<div class="ob-chips">' + chipsHtml + '</div>'
      + '<button class="ob-btn" data-onclick="_obNext">Continue →</button>'
      + '<button class="ob-skip" data-onclick="_obNext">Skip this step</button>'
      + '</div>';
  }

  // ── Step 2: Avatar picker ─────────────────────────────────────
  else if (_obStep === 2) {
    var avatarGridHtml = _AV_ALL.map(function(av, i) {
      var isActive = _obData.avatarSrc === av.src;
      return '<button class="ob-av-pick' + (isActive ? ' active' : '') + '" data-onclick="_obPickAvatar" data-a0=" + i + " style="overflow:visible">'
        + '<img src="' + av.src + '" style="pointer-events:none">'
        + '</button>';
    }).join('');
    content.innerHTML =
      '<div class="ob-step">'
      + '<h1 class="ob-headline">Choose your <span>avatar</span></h1>'
      + '<p class="ob-sub">Pick one that feels like you. You can always change it later.</p>'
      + '<div class="ob-av-grid" style="overflow:visible">' + avatarGridHtml + '</div>'
      + '<button class="ob-btn" data-onclick="_obNext">Continue →</button>'
      + '<button class="ob-skip" data-onclick="_obNext">Skip this step</button>'
      + '</div>';
  }

  // ── Step 3: Feature showcase ──────────────────────────────────
  else if (_obStep === 3) {
    /* Real Fina mark for the AI feature card, not a generic robot emoji */
    var robotIconHtml = typeof finaMark === 'function' ? finaMark({size: 22, state: 'idle'}) : '<span style="font-size:20px">🤖</span>';
    /* Aligned colored icon SVGs for each feature */
    var features = [
      {
        iconHtml: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#4F8EF7" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="3"/><path d="M2 10h20"/></svg>',
        bg:'rgba(79,142,247,0.14)', title:'Accounts & Balances', desc:'Link bank, cash, GCash, Maya & credit cards in one view.'
      },
      {
        iconHtml: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>',
        bg:'rgba(16,185,129,0.14)', title:'Track Every Peso', desc:'Log expenses, income, savings & transfers in seconds.'
      },
      {
        iconHtml: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
        bg:'rgba(245,158,11,0.14)', title:'Bills & Subscriptions', desc:'Never miss a due date — get reminders before they hit.'
      },
      {
        iconHtml: robotIconHtml,
        bg:'rgba(139,92,246,0.14)', title:'Ask Fina (AI)', desc:'Your personal money coach. Reads your real data, not guesses.'
      },
    ];
    var featHtml = features.map(function(f) {
      return '<div class="ob-feat-card">'
        + '<div class="ob-feat-icon" style="background:' + f.bg + ';display:flex;align-items:center;justify-content:center">' + f.iconHtml + '</div>'
        + '<div class="ob-feat-text">'
        + '<div class="ob-feat-title">' + f.title + '</div>'
        + '<div class="ob-feat-desc">' + f.desc + '</div>'
        + '</div></div>';
    }).join('');
    content.innerHTML =
      '<div class="ob-step">'
      + '<h1 class="ob-headline">Everything you <span>need</span></h1>'
      + '<p class="ob-sub" style="margin-bottom:20px">Fintra is built for how Filipinos actually manage money.</p>'
      + '<div class="ob-features">' + featHtml + '</div>'
      + '<button class="ob-btn" data-onclick="_obNext">Got it, let\'s go →</button>'
      + '</div>';
  }

  // ── Step 4: Gesture tips / navigation hints ────────────────────
  else if (_obStep === 4) {
    var name4 = _obData.name ? _obData.name.split(' ')[0] : 'you';
    var bubbleId4 = 'ob-fina-bubble-4';
    var tips = [
      { icon: '👆', title: 'Swipe right → open sidebar', text: 'Access your accounts, settings & profile anytime.' },
      { icon: '↕️', title: 'Pull down to refresh', text: 'Reload balances and transactions on any screen.' },
      { icon: (typeof finaMark === 'function' ? finaMark({size: 22, state: 'idle'}) : '🤖'), title: 'Tap Fina anytime', text: 'Ask me anything about your money — I\'ve got the context.' },
    ];
    var tipsHtml = tips.map(function(t) {
      return '<div class="ob-tip-card">'
        + '<div class="ob-tip-icon">' + t.icon + '</div>'
        + '<div class="ob-tip-text"><strong>' + t.title + '</strong>' + t.text + '</div>'
        + '</div>';
    }).join('');
    content.innerHTML =
      '<div class="ob-step">'
      + _obFinaHtml(true)
      + '<div class="ob-fina-bubble" id="' + bubbleId4 + '">'
      + '<span class="ob-fina-typing"><span></span><span></span><span></span></span>'
      + '</div>'
      + '<div class="ob-tips">' + tipsHtml + '</div>'
      + '<button class="ob-btn" data-onclick="_obNext">Almost there →</button>'
      + '</div>';
    setTimeout(function(){
      var bubble = document.getElementById(bubbleId4);
      if (bubble) bubble.innerHTML = 'Quick tips for ' + name4 + '! Here\'s how to get around Fintra like a pro 🚀';
    }, 900);
  }

  // ── Step 5: Storage mode choice ───────────────────────────────
  else if (_obStep === 5) {
    var _isLocal = window._localMode;
    var _cloudBorder = !_isLocal ? '#4F8EF7' : 'rgba(255,255,255,0.12)';
    var _cloudBg     = !_isLocal ? 'rgba(79,142,247,0.10)' : 'rgba(255,255,255,0.04)';
    var _localBorder = _isLocal  ? '#F59E0B' : 'rgba(255,255,255,0.12)';
    var _localBg     = _isLocal  ? 'rgba(245,158,11,0.08)' : 'rgba(255,255,255,0.04)';
    var _cloudBadge  = !_isLocal ? '<span style="margin-left:auto;flex-shrink:0;font-size:10px;font-weight:600;background:rgba(79,142,247,0.20);color:#4F8EF7;padding:2px 8px;border-radius:99px;border:1px solid rgba(79,142,247,0.30);align-self:center;letter-spacing:0.03em">ACTIVE</span>' : '';
    var _localBadge  = _isLocal  ? '<span style="margin-left:auto;flex-shrink:0;font-size:10px;font-weight:600;background:rgba(245,158,11,0.18);color:#F59E0B;padding:2px 8px;border-radius:99px;border:1px solid rgba(245,158,11,0.30);align-self:center;letter-spacing:0.03em">ACTIVE</span>' : '';
    content.innerHTML =
      '<div class="ob-step">'
      + '<div class="ob-hero-icon"><div class="ob-hero-icon-inner">💾</div></div>'
      + '<h1 class="ob-headline">Where should your<br><span>data live?</span></h1>'
      + '<p class="ob-sub">You can change this anytime from Settings.</p>'
      + '<div style="display:flex;flex-direction:column;gap:10px;width:100%;max-width:340px;margin:0 auto 22px">'
      + '<button data-onclick="_obPickStorage" data-a0="cloud" style="display:flex;align-items:flex-start;gap:14px;padding:15px 16px;border-radius:16px;border:2px solid ' + _cloudBorder + ';background:' + _cloudBg + ';cursor:pointer;font-family:inherit;text-align:left;transition:all 0.18s;width:100%;-webkit-tap-highlight-color:transparent">'
      + '<span style="font-size:26px;flex-shrink:0;margin-top:1px">☁️</span>'
      + '<div style="flex:1;min-width:0">'
      + '<div style="font-size:14px;font-weight:600;color:#fff;margin-bottom:3px">Cloud Sync</div>'
      + '<div style="font-size:12px;color:rgba(255,255,255,0.48);line-height:1.45">Sign in to sync across all your devices. Automatic backups.</div>'
      + '</div>' + _cloudBadge + '</button>'
      + '<button data-onclick="_obPickStorage" data-a0="local" style="display:flex;align-items:flex-start;gap:14px;padding:15px 16px;border-radius:16px;border:2px solid ' + _localBorder + ';background:' + _localBg + ';cursor:pointer;font-family:inherit;text-align:left;transition:all 0.18s;width:100%;-webkit-tap-highlight-color:transparent">'
      + '<span style="flex-shrink:0;display:flex;align-items:center;justify-content:center;width:28px;height:28px;margin-top:1px"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="rgba(255,255,255,0.7)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="9" y1="18.5" x2="15" y2="18.5"/></svg></span>'
      + '<div style="flex:1;min-width:0">'
      + '<div style="font-size:14px;font-weight:600;color:#fff;margin-bottom:3px">Local Only</div>'
      + '<div style="font-size:12px;color:rgba(255,255,255,0.48);line-height:1.45">No account needed. Data stays on this device only.</div>'
      + '</div>' + _localBadge + '</button>'
      + '</div>'
      + '<button class="ob-btn" data-onclick="_obNext">Continue →</button>'
      + '</div>';
  }

  // ── Step 6: All set — show selected avatar ────────────────────
  else if (_obStep === 6) {
    var firstName = _obData.name ? _obData.name.split(' ')[0] : '';
    /* Show selected avatar or fallback robot */
    var avatarHtml;
    if (_obData.avatarSrc) {
      avatarHtml = '<div class="ob-ready-ring">'
        + '<div class="ob-ready-inner" style="width:100%;height:100%;border-radius:50%;overflow:hidden;position:relative;z-index:1">'
        + '<img src="' + _obData.avatarSrc + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">'
        + '</div></div>';
    } else {
      avatarHtml = '<div class="ob-ready-ring"><div class="ob-ready-inner" style="font-size:42px">🤖</div></div>';
    }
    content.innerHTML =
      '<div class="ob-step">'
      + avatarHtml
      + '<h1 class="ob-headline">' + (firstName ? 'Ready, <span>' + firstName + '</span>!' : 'You\'re <span>all set!</span>') + '</h1>'
      + '<p class="ob-sub">Start by adding your first account. Fintra will help you track everything from there.</p>'
      + '<button class="ob-btn" data-onclick="_obFinish">Launch Fintra →</button>'
      + '</div>';
  }
}

function _obPickAge(g) {
  _obData.age = g;
  document.querySelectorAll('#ob-content .ob-chip').forEach(function(btn) {
    btn.classList.toggle('active', btn.textContent.trim() === g || btn.innerText.trim() === g);
  });
}

function _obPickGender(g) { /* legacy - unused */ }
function _obPickAvatar(idx) {
  var av = _AV_ALL[idx];
  if (!av) return;
  _obData.avatarSrc = av.src;
  _obData.gender = av.gender || '';
  document.querySelectorAll('#ob-content .ob-av-pick').forEach(function(btn, i) {
    btn.classList.toggle('active', i === idx);
  });
}

function _obValidateStep0() {
  if (!_obData.name) {
    var el = document.getElementById('ob-name-input');
    if (el) { el.classList.add('error'); el.focus(); setTimeout(function(){ el.classList.remove('error'); }, 600); }
    return;
  }
  _obNext();
}

function _obNext() {
  if (_obStep < _OB_TOTAL - 1) { _obStep++; _obRender(); }
  else { _obFinish(); }
}

/* ── Storage mode picker — called from Step 5 cards ── */
function _obPickStorage(mode) {
  _obData.storage = mode;
  // Apply immediately so window._localMode is accurate for subsequent re-renders
  var goingLocal = (mode === 'local');
  localStorage.setItem('fintra_storage_mode', mode);
  window._localMode = goingLocal;
  if (goingLocal) {
    // Detach any Firebase listeners that may already be running
    try { if (typeof _detachAllListeners === 'function') _detachAllListeners(); } catch(e) {}
  }
  // Re-render this step to update the active card styling
  _obRender();
}

function _obFinish() {
  if (_obData.name) {
    S.profile.name = _obData.name;
    var ap = getActiveProfile(); if (ap) ap.name = _obData.name;
  }
  if (_obData.age)    S.profile.age    = _obData.age;
  if (_obData.avatarSrc) {
    S.profile.photo = _obData.avatarSrc;
    var apAv = getActiveProfile(); if (apAv) apAv.photo = _obData.avatarSrc;
  }
  if (_obData.gender) {
    S.profile.gender = _obData.gender;
    if (!S.profile.photo) {
      var defAv = _defaultAvatar();
      if (defAv) { S.profile.photo = defAv; var ap2=getActiveProfile(); if(ap2) ap2.photo=defAv; }
    }
  }
  try { save(); } catch(e) {}
  try { applyPhoto(); } catch(e) {}
  try { renderProfile && renderProfile(); } catch(e) {}

  // ── Apply storage mode chosen in onboarding ──────────────────
  // If user chose Local, ensure the app stays in local mode and
  // never redirects to the auth screen after the overlay closes.
  if (window._localMode) {
    var authScreen = document.getElementById('fb-auth-screen');
    var appEl  = document.getElementById('main-app') || document.querySelector('.app');
    var botNav = document.getElementById('bottom-nav');
    var chip   = document.getElementById('fb-user-chip');
    if (authScreen) authScreen.classList.add('hidden');
    if (appEl)  { appEl.style.visibility = ''; appEl.style.display = ''; }
    if (botNav) { botNav.style.visibility = ''; botNav.style.display = ''; }
    if (chip)   chip.style.display = 'none';
    // FIX Bug2: fbBootApp() was never called here, leaving the UI uninitialized
    // (empty account dropdowns, blank dashboard) after completing onboarding in
    // local mode. onAuthStateChanged already fired with _localMode=false at that
    // point, so we must boot manually now that mode has been set.
    try { if (typeof _rebuildAccMap === 'function') _rebuildAccMap(); } catch(e) {}
    try { if (typeof fbBootApp === 'function') fbBootApp(); } catch(e) {}
    try { if (typeof _updateStorageChip === 'function') setTimeout(_updateStorageChip, 600); } catch(e) {}
  } else if (_obData.storage === 'cloud') {
    // Cloud chosen — show auth screen if not already signed in
    var _user = (typeof _auth !== 'undefined') ? _auth.currentUser : null;
    if (!_user) {
      var authScr2 = document.getElementById('fb-auth-screen');
      var appEl2   = document.getElementById('main-app') || document.querySelector('.app');
      var botNav2  = document.getElementById('bottom-nav');
      if (authScr2) { authScr2.classList.remove('hidden'); }
      if (appEl2)   appEl2.style.display = 'none';
      if (botNav2)  botNav2.style.display = 'none';
      closeOnboarding();
      // Show a friendly nudge at the top of the auth card
      setTimeout(function() {
        var card = document.querySelector('#fb-auth-screen .fb-card');
        if (card && !document.getElementById('ob-cloud-nudge')) {
          var nudge = document.createElement('div');
          nudge.id = 'ob-cloud-nudge';
          nudge.style.cssText = 'background:rgba(79,142,247,0.10);border:1px solid rgba(79,142,247,0.25);border-radius:10px;padding:9px 13px;margin-bottom:14px;font-size:12px;color:rgba(150,195,255,0.90);line-height:1.45;text-align:center';
          nudge.innerHTML = '☁️ <strong>Almost there!</strong> Sign in or create an account to enable cloud sync.';
          card.insertBefore(nudge, card.firstChild);
        }
      }, 180);
      return;
    }
  }

  closeOnboarding();
  setTimeout(function(){ try { document.getElementById('btn-open-account').click(); } catch(e) {} }, 400);
}

function closeOnboarding() {
  var overlay = document.getElementById('onboarding-overlay');
  if (overlay) overlay.classList.remove('show');
  localStorage.setItem('fintra_onboarded_v1', '1');
}

function _previewOnboarding() {
  _obStep = 0;
  _obData = { name:'', age:'', gender:'', avatarSrc:'', storage: window._localMode ? 'local' : 'cloud' };
  _obRender();
  var overlay = document.getElementById('onboarding-overlay');
  if (overlay) overlay.classList.add('show');
}

function showOnboarding() {
  if (localStorage.getItem('fintra_onboarded_v1')) return;
  _previewOnboarding();
}

// Auto-trigger on first boot
document.addEventListener('fintra-booted', function() {
  setTimeout(showOnboarding, 800);
});
