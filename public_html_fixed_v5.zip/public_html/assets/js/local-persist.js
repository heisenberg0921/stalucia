/* ══════════════════════════════════════════════════════════════
   LOCAL-FIRST DURABILITY
   Fintra stores your data in this device's localStorage. Mobile
   browsers (especially iOS Safari / PWAs) can evict that storage
   under pressure or after periods of inactivity. Asking for
   "persistent" storage tells the browser to keep it and not evict.
   Safe no-op on browsers that don't support the API.
   ══════════════════════════════════════════════════════════════ */
(function () {
  try {
    if (navigator.storage && typeof navigator.storage.persist === 'function') {
      navigator.storage.persisted()
        .then(function (already) {
          if (!already) return navigator.storage.persist();
        })
        .then(function (granted) {
          if (granted === true) {
            console.info('[Fintra] Persistent local storage granted.');
          }
        })
        .catch(function () { /* ignore — best effort */ });
    }
  } catch (e) { /* ignore */ }
})();
