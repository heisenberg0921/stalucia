
(function(){
  function $(id){return document.getElementById(id);}

  // Format yyyy-mm-dd as a smart relative label.
  // Today / Yesterday / Tomorrow / weekday (within last 6 days)
  // / "Apr 23" (same year) / "Apr 23, 2025" (other year).
  function fmtSmartDate(yyyymmdd){
    if(!yyyymmdd) return 'Today';
    var p=String(yyyymmdd).split('-');
    if(p.length!==3) return yyyymmdd;
    var d=new Date(+p[0], +p[1]-1, +p[2]);
    if(isNaN(d.getTime())) return yyyymmdd;
    var today=new Date(); today.setHours(0,0,0,0);
    d.setHours(0,0,0,0);
    var diff=Math.round((d-today)/86400000);
    if(diff===0)  return 'Today';
    if(diff===-1) return 'Yesterday';
    if(diff===1)  return 'Tomorrow';
    if(diff>-7 && diff<0){
      try { return d.toLocaleDateString(undefined,{weekday:'short'}); }
      catch(e){ return d.toDateString().slice(0,3); }
    }
    var sameYear=d.getFullYear()===today.getFullYear();
    try {
      return d.toLocaleDateString(undefined, sameYear
        ? {month:'short', day:'numeric'}
        : {month:'short', day:'numeric', year:'numeric'});
    } catch(e){
      return (d.getMonth()+1)+'/'+d.getDate()+(sameYear?'':'/'+d.getFullYear());
    }
  }

  // Treat anything other than today as "custom" so we tint the pill.
  function isToday(yyyymmdd){
    if(!yyyymmdd) return true;
    var t=new Date();
    var s=t.getFullYear()+'-'+String(t.getMonth()+1).padStart(2,'0')+'-'+String(t.getDate()).padStart(2,'0');
    return yyyymmdd===s;
  }

  function refreshLabel(){
    var inp=$('csh-date'), lbl=$('csh-date-pill-lbl'), row=document.querySelector('.csh-date-row');
    if(!inp||!lbl) return;
    lbl.textContent = fmtSmartDate(inp.value);
    if(row) row.classList.toggle('has-custom', !isToday(inp.value));
  }

  function init(){
    var inp=$('csh-date'); if(!inp) return;

    // Update label when user picks a date.
    inp.addEventListener('change', refreshLabel);
    inp.addEventListener('input',  refreshLabel);

    // BUG 2 FIX (part 2): on browsers where clicking a transparent date input
    // only focuses it (e.g. desktop Firefox), explicitly open the calendar.
    // Wrapped in try/catch — showPicker throws if the picker is already open
    // (harmless) or unsupported (we fall back to native behavior).
    inp.addEventListener('click', function(){
      try { if (typeof this.showPicker === 'function') this.showPicker(); } catch(e) {}
    });

    // Patch openSheet so the label refreshes after the date is reset to today.
    var origOpen=window._calcSheetOpen;
    if(typeof origOpen==='function'){
      window._calcSheetOpen=function(t){
        origOpen(t);
        // Defer to next tick so the input.value=todayStr() inside has applied.
        setTimeout(refreshLabel,0);
      };
    }

    refreshLabel();
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
