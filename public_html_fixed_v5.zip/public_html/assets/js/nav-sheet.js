
// ── NAV SHEET — open / close ────────────────────────────────────────────────
(function(){
  var _nsOpen = false;

  window.openNavSheet = function(){
    if(window.innerWidth > 900) return; // desktop: sidebar always visible
    _nsOpen = true;

    // ── Sync profile avatar: copy av-chip's innerHTML (photo or initial) ──
    var avChip  = document.getElementById('av-chip');
    var nshAv   = document.getElementById('nsh-avatar');
    if(avChip && nshAv) {
      nshAv.innerHTML = avChip.innerHTML;
      // If a photo is present remove the text-initial span so only img shows
      var img = nshAv.querySelector('img');
      if(img) {
        img.style.cssText = 'width:100%;height:100%;object-fit:cover;border-radius:50%;display:block';
        nshAv.style.border = '2px solid rgba(37,99,235,0.35)';
      } else {
        nshAv.style.border = '';
      }
    }

    // ── Sync name ──
    var nameSrc = document.getElementById('chip-name');
    var nameDst = document.getElementById('nsh-profile-name');
    if(nameSrc && nameDst) nameDst.textContent = nameSrc.textContent;

    // ── Hide the Fina FAB so it doesn't float above the sheet ──
    var fab = document.getElementById('fina-fab');
    if(fab) { fab.dataset.nshHidden = '1'; fab.style.opacity = '0'; fab.style.pointerEvents = 'none'; }

    var overlay = document.getElementById('nav-sheet-overlay');
    var sheet   = document.getElementById('nav-sheet');
    overlay.style.display = 'block';
    sheet.style.display   = 'block';
    requestAnimationFrame(function(){
      requestAnimationFrame(function(){
        overlay.classList.add('show');
        sheet.classList.add('open');
      });
    });
    document.body.style.overflow = 'hidden';
  };

  window.closeNavSheet = function(){
    if(!_nsOpen) return;
    _nsOpen = false;
    var overlay = document.getElementById('nav-sheet-overlay');
    var sheet   = document.getElementById('nav-sheet');
    overlay.classList.remove('show');
    sheet.classList.remove('open');
    document.body.style.overflow = '';

    // ── Restore Fina FAB ──
    var fab = document.getElementById('fina-fab');
    if(fab && fab.dataset.nshHidden) {
      delete fab.dataset.nshHidden;
      fab.style.opacity = '';
      fab.style.pointerEvents = '';
    }

    // Hide sheet after transition
    setTimeout(function(){
      overlay.style.display = 'none';
      sheet.style.display   = 'none';
    }, 380);
  };

  // Close on Escape
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape') window.closeNavSheet();
  });

  // Swipe-down gesture to close
  (function(){
    var startY = 0, dragging = false;
    var sheet = document.getElementById('nav-sheet');
    if(!sheet) return;
    sheet.addEventListener('touchstart', function(e){
      startY = e.touches[0].clientY; dragging = true;
    }, {passive: true});
    sheet.addEventListener('touchend', function(e){
      if(!dragging) return;
      dragging = false;
      var dy = e.changedTouches[0].clientY - startY;
      if(dy > 60) window.closeNavSheet();
    }, {passive: true});
  })();
})();
