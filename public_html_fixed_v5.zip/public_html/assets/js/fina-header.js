
          (function mountFinaHeader(){
            var slot = document.getElementById('fina-header-avatar-slot');
            if (slot && typeof finaMark === 'function') {
              slot.innerHTML = finaMark({ size: 28, state: 'idle' });
            } else {
              setTimeout(mountFinaHeader, 30);
            }
          })();
          