
// Mount the Mark into the FAB as soon as it's defined (helper is loaded later in the page)
(function(){
  function mount(){
    var slot = document.getElementById('fina-fab-mark-slot');
    if (slot && typeof finaMark === 'function') {
      slot.innerHTML = finaMark({ size: 64, state: 'idle' });
    } else {
      setTimeout(mount, 30);
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mount);
  } else {
    mount();
  }
})();
