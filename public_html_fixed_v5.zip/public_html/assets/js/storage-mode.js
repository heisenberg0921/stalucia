
/* ══════════════════════════════════════════════════════════════
   STORAGE MODE ENGINE
   ══════════════════════════════════════════════════════════════ */

function openStorageModeSheet() {
  var sheet = document.getElementById('storage-mode-sheet');
  var backdrop = document.getElementById('storage-sheet-backdrop');
  if (!sheet) return;
  _smsRefreshUI();
  sheet.style.display = 'block';
  backdrop.style.display = 'block';
  requestAnimationFrame(function() {
    requestAnimationFrame(function() {
      sheet.style.transform = 'translateY(0)';
      backdrop.style.opacity = '1';
    });
  });
}

function closeStorageModeSheet() {
  var sheet = document.getElementById('storage-mode-sheet');
  var backdrop = document.getElementById('storage-sheet-backdrop');
  if (!sheet) return;
  sheet.style.transform = 'translateY(100%)';
  backdrop.style.opacity = '0';
  setTimeout(function() {
    sheet.style.display = 'none';
    backdrop.style.display = 'none';
  }, 340);
}

function _smsRefreshUI() {
  var isLocal = window._localMode;
  var blue = '#2563EB';

  // Cloud card
  var cc = document.getElementById('sms-cloud-card');
  var ck = document.getElementById('sms-cloud-check');
  var ci = document.getElementById('sms-cloud-icon');
  if (cc) cc.style.borderColor = isLocal ? 'var(--border)' : blue;
  if (cc) cc.style.background  = isLocal ? '' : 'rgba(37,99,235,0.04)';
  if (ck) { ck.style.background = isLocal ? '' : blue; ck.style.borderColor = isLocal ? 'var(--border)' : blue; ck.innerHTML = isLocal ? '' : '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>'; }

  // Local card
  var lc = document.getElementById('sms-local-card');
  var lk = document.getElementById('sms-local-check');
  var amber = '#D97706';
  if (lc) lc.style.borderColor = isLocal ? amber : 'var(--border)';
  if (lc) lc.style.background  = isLocal ? 'rgba(217,119,6,0.04)' : '';
  if (lk) { lk.style.background = isLocal ? amber : ''; lk.style.borderColor = isLocal ? amber : 'var(--border)'; lk.innerHTML = isLocal ? '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>' : ''; }

  // Profile row subtitle
  var sub = document.getElementById('prof-storage-sub');
  if (sub) sub.textContent = isLocal ? 'Local Only' : 'Cloud Sync';
}

function _setStorageMode(mode) {
  var alreadyLocal = window._localMode;
  var goingLocal   = (mode === 'local');

  if (goingLocal === alreadyLocal) { closeStorageModeSheet(); return; }

  var msg = goingLocal
    ? 'Switch to Local Only?\n\nYour data will stay on this device only. Cloud sync will be paused. You can switch back anytime.\n\nExport a backup first if you want to keep a copy.'
    : 'Switch to Cloud Sync?\n\nYou\'ll be signed in to sync your data across devices. Your current local data will be kept.';

  if (!confirm(msg)) return;

  localStorage.setItem(STORAGE_MODE_KEY, mode);
  window._localMode = goingLocal;
  _smsRefreshUI();
  _updateStorageChip();

  if (goingLocal) {
    // Detach Firebase listeners, stop further cloud writes
    try { if (typeof _detachAllListeners === 'function') _detachAllListeners(); } catch(e) {}
    closeStorageModeSheet();
    if (typeof toast === 'function') toast('🗂 Switched to Local Only mode', 'info');
  } else {
    // Cloud: need to sign in (or re-attach if already signed in)
    closeStorageModeSheet();
    var user = typeof _auth !== 'undefined' ? _auth.currentUser : null;
    if (user) {
      if (typeof fbSaveNow === 'function') fbSaveNow();
      try { if (typeof _attachRealtimeListeners === 'function') _attachRealtimeListeners(user.uid, S.activeProfileId || 'p1'); } catch(e) {}
      if (typeof toast === 'function') toast('☁ Cloud Sync enabled', 'success');
    } else {
      // No user signed in — send to auth screen
      var authScreen = document.getElementById('fb-auth-screen');
      var appEl = document.getElementById('main-app') || document.querySelector('.app');
      var botNav = document.getElementById('bottom-nav');
      if (authScreen) authScreen.classList.remove('hidden');
      if (appEl)  appEl.style.display = 'none';
      if (botNav) botNav.style.display = 'none';
    }
  }
}

/* ── Sync chip: show local mode indicator ── */
function _updateStorageChip() {
  var chip = document.getElementById('fb-sync-chip');
  if (!chip) return;
  if (window._localMode) {
    chip.innerHTML = '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="9" y1="18.5" x2="15" y2="18.5"/></svg><span>Local</span>';
    chip.style.display = 'inline-flex';
    chip.style.alignItems = 'center';
    chip.style.gap = '4px';
    chip.style.background = 'rgba(217,119,6,0.12)';
    chip.style.color = '#D97706';
    chip.style.borderColor = 'rgba(217,119,6,0.3)';
    chip.style.display = 'flex';
  }
  // Cloud mode: leave chip alone (fbSetSyncChip handles it)
}

/* ── Export / Import ── */
function _exportLocalData() {
  try {
    var data = JSON.stringify(S, null, 2);
    var blob = new Blob([data], { type: 'application/json' });
    var url  = URL.createObjectURL(blob);
    var a    = document.createElement('a');
    var d    = new Date(); var pad = function(n){return String(n).padStart(2,'0');};
    a.download = 'fintra-backup-' + d.getFullYear() + pad(d.getMonth()+1) + pad(d.getDate()) + '.json';
    a.href = url;
    a.click();
    URL.revokeObjectURL(url);
    if (typeof toast === 'function') toast('✓ Backup downloaded', 'success');
  } catch(e) {
    if (typeof toast === 'function') toast('Export failed: ' + e.message, 'error');
  }
}

function _importLocalData() {
  var inp = document.getElementById('sms-import-input');
  if (inp) inp.click();
}

function _handleImportFile(ev) {
  var file = ev.target.files && ev.target.files[0];
  if (!file) return;
  var reader = new FileReader();
  reader.onload = function(e) {
    try {
      var parsed = JSON.parse(e.target.result);
      if (!parsed || typeof parsed !== 'object') throw new Error('Invalid file');
      if (!confirm('Import this backup? Your current data will be replaced.')) return;
      S = parsed;
      save();
      if (typeof fbBootApp === 'function') fbBootApp();
      closeStorageModeSheet();
      if (typeof toast === 'function') toast('✓ Data imported successfully', 'success');
    } catch(err) {
      if (typeof toast === 'function') toast('Import failed: ' + err.message, 'error');
    }
    ev.target.value = '';
  };
  reader.readAsText(file);
}

/* ── Init on load ── */
document.addEventListener('DOMContentLoaded', function() {
  _smsRefreshUI();
  if (window._localMode) setTimeout(_updateStorageChip, 800);
});
