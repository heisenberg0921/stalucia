
// ── Custom date display helpers ──────────────────────────────
function _fmtDateDisp(val) {
  if (!val) return null;
  // val is YYYY-MM-DD → display as MM-DD-YYYY
  var parts = val.split('-');
  if (parts.length !== 3) return null;
  return parts[1] + '-' + parts[2] + '-' + parts[0];
}

function _updateDateDisp(inputOrId, dispOrId) {
  var inp = typeof inputOrId === 'string' ? document.getElementById(inputOrId) : inputOrId;
  var disp = typeof dispOrId === 'string' ? document.getElementById(dispOrId) : dispOrId;
  if (!inp || !disp) return;
  var formatted = _fmtDateDisp(inp.value);
  if (formatted) {
    disp.textContent = formatted;
    disp.classList.remove('placeholder');
  } else {
    disp.textContent = 'Pick date';
    disp.classList.add('placeholder');
  }
}

// Init displays on load and after any renderPeople/switchPeopleTab calls
function _initAllDateDisps() {
  document.querySelectorAll('.lf-date-field input[type="date"]').forEach(function(inp) {
    var disp = inp.parentNode.querySelector('.lf-date-display');
    if (disp) _updateDateDisp(inp, disp);
  });
  // Also handle the cr- chart inputs by ID
  _updateDateDisp('cr-from-date', 'cr-from-disp');
  _updateDateDisp('cr-to-date', 'cr-to-disp');
}

document.addEventListener('DOMContentLoaded', _initAllDateDisps);
// Also run after a short delay for dynamically shown panels
document.addEventListener('panel-shown', _initAllDateDisps);
