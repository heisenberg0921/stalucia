
(function(){
'use strict';

// ── Feedback: haptic + sound (Minimal style) ─────────────────────
// Keeps the original ftHaptic(type) API so every existing call site
// (nav, primary buttons, PTR arm/trigger) gets sound for free.
// Tones are synthesized via Web Audio — zero network, zero bytes.
// Preferences persist in localStorage (fb_haptic, fb_sound).
(function(){
  var _ctx = null;
  var _unlocked = false;
  var _lastTap = 0;
  var _supportsVib = typeof navigator !== 'undefined' && 'vibrate' in navigator;

  // Prefs: default both ON, persist as '0' = off
  var _prefs = {
    haptic: localStorage.getItem('fb_haptic') !== '0',
    sound:  localStorage.getItem('fb_sound')  !== '0'
  };

  function _getCtx(){
    if (_ctx) return _ctx;
    try { _ctx = new (window.AudioContext || window.webkitAudioContext)(); }
    catch(e){ _ctx = null; }
    return _ctx;
  }
  function _unlock(){
    if (_unlocked) return;
    var c = _getCtx(); if (!c) return;
    if (c.state === 'suspended') { try { c.resume(); } catch(e){} }
    _unlocked = c.state === 'running';
  }
  // First-gesture audio unlock (iOS/Chrome autoplay policy)
  ['pointerdown','touchstart','keydown'].forEach(function(evt){
    document.addEventListener(evt, _unlock, {passive:true, capture:true});
  });

  // Atomic tone with short envelope. Minimal style: ≤25ms, ≤0.035 volume.
  function _tone(freq, duration, volume, delay, type){
    if (!_prefs.sound) return;
    if (!_ctx || _ctx.state !== 'running') return;
    try {
      var osc = _ctx.createOscillator();
      var gain = _ctx.createGain();
      osc.type = type || 'sine';
      osc.frequency.value = freq;
      osc.connect(gain); gain.connect(_ctx.destination);
      var t0 = _ctx.currentTime + (delay || 0);
      gain.gain.setValueAtTime(0, t0);
      gain.gain.linearRampToValueAtTime(volume, t0 + 0.004);
      gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
      osc.start(t0);
      osc.stop(t0 + duration + 0.02);
    } catch(e){}
  }

  function _vib(pattern){
    if (!_prefs.haptic || !_supportsVib) return;
    try { navigator.vibrate(pattern); } catch(e){}
  }

  // Public API — same signature as before, now with sound
  window.ftHaptic = function(type){
    switch(type){
      case 'light':
        // Rate-limit taps to prevent audio chatter on rapid events
        var now = performance.now();
        if (now - _lastTap < 40) { _vib(4); return; }
        _lastTap = now;
        _vib(4);
        _tone(1400, 0.010, 0.018);
        break;
      case 'medium':
        _vib(10);
        _tone(1100, 0.020, 0.028);
        break;
      case 'heavy':
        _vib(18);
        _tone(900, 0.030, 0.032);
        break;
      case 'success':
        _vib([4, 30, 4]);
        _tone(1100, 0.015, 0.025);
        _tone(1400, 0.020, 0.025, 0.04);
        break;
      case 'error':
        _vib([18, 40, 18]);
        _tone(300, 0.040, 0.035);
        break;
      default:
        _vib(4);
        _tone(1400, 0.010, 0.018);
    }
  };

  // Preference setters — call from a Profile toggle
  window.ftFeedbackPrefs = {
    get: function(){ return {haptic:_prefs.haptic, sound:_prefs.sound}; },
    setHaptic: function(v){ _prefs.haptic = !!v; localStorage.setItem('fb_haptic', v?'1':'0'); },
    setSound:  function(v){ _prefs.sound  = !!v; localStorage.setItem('fb_sound',  v?'1':'0'); },
    supportsHaptic: _supportsVib
  };

  // ── Arrival click: fires when a sheet/modal/drawer reaches rest ──
  // Deliberately softer + higher than 'light' tap so it reads as
  // "the thing settled" rather than another button click.
  var _lastArrive = 0;
  window.ftArrive = function(){
    var now = performance.now();
    if (now - _lastArrive < 250) return; // dedupe multi-property transitionend
    _lastArrive = now;
    _vib(3);
    _tone(1600, 0.008, 0.014);
  };

  // Wire arrival to CSS transition completions on known containers.
  // Filters on the transformed property to avoid firing on opacity/bg transitions.
  function _wireArrive(selector, prop, openClass){
    document.addEventListener('transitionend', function(e){
      if (e.propertyName !== prop) return;
      var el = e.target;
      if (!el.matches || !el.matches(selector)) return;
      if (!el.classList.contains(openClass)) return; // only on open, not close
      ftArrive();
    }, true);
  }
  _wireArrive('.bn-sheet',        'transform', 'open'); // bottom-nav sheet
  _wireArrive('.sidebar',         'right',     'open'); // sidebar drawer
  _wireArrive('.modal-overlay',   'opacity',   'show'); // modal backdrop
  _wireArrive('.modal',           'transform', 'show'); // modal itself (if animated separately)
})();

// ── 1. Panel direction + haptic on nav ──────────────────────────
var _prevNavIdx = typeof _currentPanelIndex !== 'undefined' ? _currentPanelIndex : 0;
var _origGoPanel = window.goPanel;
window.goPanel = function(name){
  var toIdx = (typeof PANELS !== 'undefined') ? PANELS.indexOf(name) : 0;
  document.documentElement.setAttribute('data-nav-dir', toIdx >= _prevNavIdx ? 'fwd' : 'back');
  _prevNavIdx = toIdx;
  ftHaptic('light');
  _origGoPanel(name);
};

// Bottom nav + sidebar nav haptics
document.querySelectorAll('.bn-item,.nav-btn').forEach(function(b){
  b.addEventListener('click', function(){ ftHaptic('light'); });
});
// Primary / danger button haptics
document.addEventListener('click', function(e){
  if(e.target.closest('.btn-primary,.btn-add')) ftHaptic('medium');
  if(e.target.closest('.btn-danger'))           ftHaptic('error');
}, true);

// ── 2. countUp utility ──────────────────────────────────────────
window.ftCountUp = function(el, end, opts){
  if(!el || isNaN(end)) return;
  opts = opts||{};
  var dur     = opts.duration||750;
  var decimals = opts.decimals !== undefined ? opts.decimals : 2;
  var prefix  = opts.prefix||'';
  var suffix  = opts.suffix||'';
  var t0 = null;
  var ease = function(t){ return 1-Math.pow(1-t,3); };
  var fmt  = function(n){
    return prefix + n.toFixed(decimals).replace(/\B(?=(\d{3})+(?!\d))/g,',') + suffix;
  };
  (function tick(ts){
    if(!t0) t0=ts;
    var p = Math.min((ts-t0)/dur,1);
    el.textContent = fmt(ease(p)*end);
    if(p<1) requestAnimationFrame(tick);
    else    el.textContent = fmt(end);
  })(performance.now());
};

// Hook countUp into dashboard render
(function(){
  var _oDash = window.renderDash;
  if(typeof _oDash !== 'function') return;
  window.renderDash = function(){
    _oDash.apply(this, arguments);
    setTimeout(function(){
      [{ id:'d-assets', prefix:'₱' }, { id:'d-credit', prefix:'₱' }, { id:'d-mflow', prefix:'' }]
      .forEach(function(d){
        var el = document.getElementById(d.id); if(!el) return;
        var neg = el.textContent.trim().startsWith('-');
        var val = parseFloat((el.textContent||'0').replace(/[^0-9.-]/g,''));
        if(!isNaN(val)) ftCountUp(el, val, { prefix: neg ? '-'+d.prefix : d.prefix, decimals:2 });
      });
    },60);
  };
})();

// ── 3. Skeleton screens ─────────────────────────────────────────
window.ftSkelHTML = function(n){
  n=n||5; var h='';
  for(var i=0;i<n;i++){
    var w1 = ['w75','w55','w75','w55','w75'][i%5];
    var w2 = ['w40','w55','w40','w40','w55'][i%5];
    h += '<div class="ft-skel-row">'
       + '<div class="ft-skel ft-skel-icon"></div>'
       + '<div class="ft-skel-body">'
       + '<div class="ft-skel ft-skel-line '+w1+'"></div>'
       + '<div class="ft-skel ft-skel-line '+w2+'"></div>'
       + '</div>'
       + '<div class="ft-skel ft-skel-amt"></div>'
       + '</div>';
  }
  return h;
};

// Inject skeleton when switching to data panels
(function(){
  var skelTargets = {
    expense:  '#log-expense-mob',
    income:   '#log-income-mob',
    transfer: '#log-transfer-mob',
    bills:    '#bills-list',
    accounts: '#bank-grid',
  };
  var _oGo = window.goPanel;
  window.goPanel = function(name){
    var sel = skelTargets[name];
    if(sel){ var el=document.querySelector(sel); if(el) el.innerHTML=ftSkelHTML(5); }
    _oGo(name);
  };
})();

// ── 4. Staggered list entry ─────────────────────────────────────
window.ftStagger = function(container){
  if(!container) return;
  void container.offsetHeight; // force reflow
  container.classList.remove('ft-stagger');
  void container.offsetHeight;
  container.classList.add('ft-stagger');
  var delay = Math.min(container.children.length,8)*38+320;
  setTimeout(function(){ container.classList.remove('ft-stagger'); }, delay);
};

// Watch list containers for new children
(function(){
  var ids = ['log-expense-mob','log-income-mob','log-transfer-mob','bills-list','bank-grid'];
  var ob = new MutationObserver(function(muts){
    muts.forEach(function(m){
      if(m.addedNodes.length>1) ftStagger(m.target);
    });
  });
  ids.forEach(function(id){
    var el=document.getElementById(id);
    if(el) ob.observe(el,{childList:true});
  });
})();

// ── 5. Swipe-to-delete on .ri rows ─────────────────────────────
(function(){
  var THRESH = 55;
  var _openItem = null;

  function wrap(ri){
    if(ri.closest('.ft-swipe-wrap')) return;
    if(!ri.parentNode) return;

    var outer = document.createElement('div');
    outer.className = 'ft-swipe-wrap';

    var bg = document.createElement('div');
    bg.className = 'ft-delete-bg';
    bg.innerHTML = '<svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/>'
      +'<path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg>'
      +'<span>Delete</span>';

    var inner = document.createElement('div');
    inner.className = 'ft-swipe-inner';

    ri.parentNode.insertBefore(outer, ri);
    outer.appendChild(bg);
    outer.appendChild(inner);
    inner.appendChild(ri);

    // Click on bg = trigger delete
    bg.addEventListener('click', function(){
      ftHaptic('heavy');
      var del = ri.querySelector('[onclick*="delete"],[onclick*="Delete"],[onclick*="remove"],[onclick*="Remove"],[data-delete],[id*="del-"]');
      if(del) del.click();
      else {
        // Animate out and remove
        outer.style.transition='all 0.28s cubic-bezier(0.4,0,0.2,1)';
        outer.style.opacity='0';
        outer.style.transform='translateX(-100%)';
        outer.style.maxHeight=outer.offsetHeight+'px';
        setTimeout(function(){
          outer.style.maxHeight='0';
          outer.style.padding='0';
          outer.style.margin='0';
          outer.style.overflow='hidden';
        },200);
      }
    });

    var sx=0, sy=0, dx=0, dragging=false, locked=false;

    inner.addEventListener('touchstart',function(e){
      sx=e.touches[0].clientX; sy=e.touches[0].clientY;
      dx=0; dragging=false; locked=false;
      if(_openItem && _openItem!==inner){
        _openItem.classList.remove('ft-open');
        _openItem.style.transform='';
        _openItem=null;
      }
    },{passive:true});

    inner.addEventListener('touchmove',function(e){
      if(locked) return;
      var cx=e.touches[0].clientX, cy=e.touches[0].clientY;
      var diffX=sx-cx, diffY=Math.abs(sy-cy);
      if(!dragging){ if(diffY>9){locked=true;return;} if(Math.abs(diffX)>7) dragging=true; }
      if(!dragging) return;
      dx=Math.max(0,Math.min(diffX,90));
      inner.style.transform='translateX(-'+dx+'px)';
      inner.style.transition='none';
    },{passive:true});

    inner.addEventListener('touchend',function(){
      if(!dragging) return;
      inner.style.transition='';
      if(dx>THRESH){
        inner.classList.add('ft-open');
        inner.style.transform='';
        _openItem=inner;
        ftHaptic('medium');
      } else {
        inner.classList.remove('ft-open');
        inner.style.transform='';
      }
    });
  }

  // Wrap existing rows
  document.querySelectorAll('.ri').forEach(wrap);

  // Wrap new rows as they're added
  var ob = new MutationObserver(function(muts){
    muts.forEach(function(m){
      m.addedNodes.forEach(function(node){
        if(node.nodeType!==1) return;
        if(node.classList && node.classList.contains('ri')) wrap(node);
        else node.querySelectorAll && node.querySelectorAll('.ri').forEach(wrap);
      });
    });
  });
  ob.observe(document.body,{childList:true,subtree:true});

  // Close open swipe on scroll
  document.querySelector('.content') && document.querySelector('.content').addEventListener('scroll',function(){
    if(_openItem){ _openItem.classList.remove('ft-open'); _openItem.style.transform=''; _openItem=null; }
  },{passive:true});

  // Close on tap outside
  document.addEventListener('touchstart',function(e){
    if(_openItem && !e.target.closest('.ft-swipe-wrap')){
      _openItem.classList.remove('ft-open'); _openItem.style.transform=''; _openItem=null;
    }
  },{passive:true});
})();

// ── 6. Pull-to-refresh — premium iOS-level gesture ──────────────
// Design goals:
//   • 100px VISUAL threshold (maps to ~200px raw drag via resistance)
//   • Resistance curve: pull = rawDrag ^ 0.55  (feels like rubber)
//   • Direction lock: ignore diagonal touches (|dy/dx| > 1.5 = scroll)
//   • Dead-zone: first 8px of movement ignored to prevent micro-triggers
//   • Trigger only on release above threshold
//   • Spring-back animation on cancel; smooth settle on trigger
//   • Clear label feedback: "Pull to refresh" → "Release to refresh"
(function(){
  var content = document.querySelector('.content');
  if (!content) return;

  // ── Build the pill indicator ────────────────────────────────────
  var ptr = document.createElement('div');
  ptr.className = 'ft-ptr';
  ptr.innerHTML =
    '<svg viewBox="0 0 24 24"><path d="M23 4v6h-6"/>'
    + '<path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>'
    + '<span class="ft-ptr-label">Pull to refresh</span>';
  content.insertBefore(ptr, content.firstChild);

  var label = ptr.querySelector('.ft-ptr-label');

  // ── Constants ───────────────────────────────────────────────────
  var DEAD_ZONE   = 22;   // px — larger dead zone ignores casual scrolls
  var THRESHOLD   = 140;  // px VISUAL pull required to arm release (firm pull needed)
  var MAX_VISUAL  = 155;  // px — pill never travels further than this
  var PILL_HIDE   = -56;  // px top when hidden (matches CSS top:-56px)
  var PILL_SHOW   = 14;   // px top when settled (loading state)
  var RAW_MIN     = 40;   // px — minimum raw drag before pill appears at all

  // Resistance: maps raw drag distance → visual displacement
  // Lower K + higher P = heavier feel throughout; requires a deliberate pull.
  // rawDrag^0.45 * K ≈ 140px visual at ~280px raw drag.
  var RESISTANCE_K = 9.5;
  var RESISTANCE_P = 0.45;
  function resist(rawDrag) {
    return Math.min(RESISTANCE_K * Math.pow(rawDrag, RESISTANCE_P), MAX_VISUAL);
  }

  // ── State ───────────────────────────────────────────────────────
  var startY      = 0;
  var startX      = 0;
  var rawDist     = 0;
  var armed       = false;   // direction-locked to vertical pull
  var locked      = false;   // direction-locked to scroll (ignore)
  var refreshing  = false;
  var aboveThresh = false;   // was threshold crossed in this pull?

  // ── Helpers ─────────────────────────────────────────────────────
  function setPillPos(visualPull, animate) {
    // visualPull: 0 = hidden, positive = revealed
    var top = PILL_HIDE + visualPull;
    var opacity = Math.min(visualPull / 20, 1);
    if (animate) {
      ptr.style.transition = 'top 0.38s cubic-bezier(0.34,1.56,0.64,1), opacity 0.22s ease';
    } else {
      ptr.style.transition = 'none';
    }
    ptr.style.top     = top + 'px';
    ptr.style.opacity = opacity.toString();
  }

  function resetPill(animate) {
    if (animate) {
      ptr.style.transition = 'top 0.34s cubic-bezier(0.16,1,0.3,1), opacity 0.22s ease';
    } else {
      ptr.style.transition = 'none';
    }
    ptr.style.top     = PILL_HIDE + 'px';
    ptr.style.opacity = '0';
    ptr.className = 'ft-ptr';
    label.textContent = 'Pull to refresh';
  }

  // ── Touch handlers ──────────────────────────────────────────────
  content.addEventListener('touchstart', function(e) {
    if (refreshing) return;
    // Only arm at the very top of the scroll container
    if (content.scrollTop !== 0) return;
    startY  = e.touches[0].clientY;
    startX  = e.touches[0].clientX;
    rawDist = 0;
    armed   = false;
    locked  = false;
    aboveThresh = false;
  }, { passive: true });

  content.addEventListener('touchmove', function(e) {
    if (refreshing || locked) return;
    if (content.scrollTop !== 0) { locked = true; return; }

    var dy = e.touches[0].clientY - startY;
    var dx = e.touches[0].clientX - startX;

    // ── Direction-lock decision (made once, after dead zone) ──────
    if (!armed) {
      var absDy = Math.abs(dy);
      var absDx = Math.abs(dx);
      // Still in dead zone — ignore
      if (absDy < DEAD_ZONE && absDx < DEAD_ZONE) return;
      // Mostly horizontal → this is a swipe, hand off to native scroll
      if (absDx > absDy * 0.75) { locked = true; return; }
      // Pulling down → arm pull-to-refresh
      if (dy > 0) { armed = true; } else { locked = true; return; }
    }

    rawDist = Math.max(0, dy - DEAD_ZONE);
    // Don't show the pill at all until user has pulled past RAW_MIN
    var effectiveDrag = Math.max(0, rawDist - RAW_MIN);
    var visual = effectiveDrag > 0 ? resist(effectiveDrag) : 0;

    // Update pill position (no CSS transition — 1:1 finger tracking)
    setPillPos(visual, false);

    // Update label & state class
    if (visual >= THRESHOLD) {
      if (!aboveThresh) {
        aboveThresh = true;
        ftHaptic('medium');                 // haptic when crossing threshold
      }
      ptr.className = 'ft-ptr ft-ptr-ready';
      label.textContent = 'Release to refresh';
    } else {
      aboveThresh = false;
      ptr.className = 'ft-ptr ft-ptr-pulling';
      label.textContent = 'Pull to refresh';
    }
  }, { passive: true });

  content.addEventListener('touchend', function() {
    if (!armed || refreshing) {
      resetPill(true);
      armed = false; locked = false;
      return;
    }

    armed = false; locked = false;

    if (aboveThresh) {
      // ── TRIGGER ─────────────────────────────────────────────────
      refreshing = true;
      ftHaptic('success');

      ptr.className = 'ft-ptr ft-ptr-loading';
      label.textContent = 'Refreshing…';

      // Animate pill to settled position
      ptr.style.transition = 'top 0.32s cubic-bezier(0.16,1,0.3,1), opacity 0.18s ease';
      ptr.style.top     = PILL_SHOW + 'px';
      ptr.style.opacity = '1';

      // ── Recompute & re-render ──────────────────────────────────
      var panelName = (typeof PANELS !== 'undefined' && typeof _currentPanelIndex !== 'undefined')
        ? PANELS[_currentPanelIndex] : null;

      setTimeout(function() {
        try {
          var _rPid = S.activeProfileId || 'p1';
          var _rPd  = S.profileData && S.profileData[_rPid];
          if (_rPd) {
            ['accounts','income','expense','transfer','credit','savings',
             'subscriptions','bills','savingsGoals','goals','installments',
             'people','loans','splits','groups','sharedExpenses'].forEach(function(col) {
              if (Array.isArray(_rPd[col])) S[col] = _rPd[col];
            });
          }
          _rebuildAccMap();
          if (typeof processSubscriptions === 'function') processSubscriptions();
          if (Array.isArray(S.people)) {
            S.people.forEach(function(p) {
              if (typeof rebuildPersonBalance === 'function') rebuildPersonBalance(p.id);
            });
          }
        } catch(err) { console.warn('[Fintra] refresh recompute:', err); }

        if (panelName) window.goPanel(panelName);
        if (typeof renderAccounts === 'function' && ge('bank-grid')) renderAccounts();
        if (typeof renderDashBills === 'function') renderDashBills();
        if (typeof renderAlerts === 'function') renderAlerts();
        if (typeof updateProfileStats === 'function') updateProfileStats();

        // Spring-back dismiss
        resetPill(true);
        refreshing = false;
        rawDist = 0;
        if (typeof toast === 'function') toast('✓ Refreshed', 'success');
      }, 900);

    } else {
      // ── CANCEL — spring back ─────────────────────────────────────
      resetPill(true);
      rawDist = 0;
    }
  });
})();

})();

/* ═══════════════════════════════════════════════════════════════
   MOTION SYSTEM — Runtime Helpers
   ═══════════════════════════════════════════════════════════════ */

/* Ripple: call createRipple(event, element) on any ripple-host */
window.createRipple = function(e, el) {
  var rect = el.getBoundingClientRect();
  var x = (e.clientX || rect.left + rect.width/2) - rect.left;
  var y = (e.clientY || rect.top + rect.height/2) - rect.top;
  var size = Math.max(rect.width, rect.height) * 2.2;
  var wave = document.createElement('span');
  wave.className = 'ripple-wave';
  wave.style.cssText = 'width:'+size+'px;height:'+size+'px;left:'+(x-size/2)+'px;top:'+(y-size/2)+'px;';
  el.appendChild(wave);
  setTimeout(function(){ wave.remove(); }, 600);
};

/* Value flash: call flashValue(element, direction) — direction: 'up'|'down' */
window.flashValue = function(el, dir) {
  el.classList.remove('value-flash-up','value-flash-down');
  void el.offsetWidth; /* force reflow */
  el.classList.add(dir === 'up' ? 'value-flash-up' : 'value-flash-down');
  setTimeout(function(){ el.classList.remove('value-flash-up','value-flash-down'); }, 400);
};

/* List enter: call listEnter(element) when adding to a list */
window.listEnter = function(el) {
  el.classList.remove('list-enter');
  void el.offsetWidth;
  el.classList.add('list-enter');
};

/* List exit: call listExit(element, callback) when removing from a list */
window.listExit = function(el, cb) {
  el.classList.add('list-exit');
  setTimeout(function(){ if(cb) cb(); }, 240);
};

/* Feedback pop: call feedbackPop(element) on success/error indicators */
window.feedbackPop = function(el) {
  el.classList.remove('feedback-pop');
  void el.offsetWidth;
  el.classList.add('feedback-pop');
};

})();
