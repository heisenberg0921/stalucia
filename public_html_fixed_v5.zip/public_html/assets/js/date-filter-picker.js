
(function(){
  var MN=['January','February','March','April','May','June','July','August','September','October','November','December'];
  var DN=['Su','Mo','Tu','We','Th','Fr','Sa'];
  var todayD=new Date();todayD.setHours(0,0,0,0);

  // State per filter type
  var _state={};
  function getState(type){
    if(!_state[type])_state[type]={vY:todayD.getFullYear(),vM:todayD.getMonth(),sFrom:null,sTo:null,picking:null};
    return _state[type];
  }

  function toYMD(d){
    if(!d)return'';
    var mm=String(d.getMonth()+1).padStart(2,'0');
    var dd=String(d.getDate()).padStart(2,'0');
    return d.getFullYear()+'-'+mm+'-'+dd;
  }
  function fmtDisp(d){
    if(!d)return'Select';
    return MN[d.getMonth()].slice(0,3)+' '+d.getDate()+', '+d.getFullYear();
  }
  function sameD(a,b){return a&&b&&a.getTime()===b.getTime();}
  function btw(d,a,b){return a&&b&&d>a&&d<b;}

  function renderCal(type){
    var st=getState(type);
    var titleEl=document.getElementById('fnf-title-'+type);
    var gridEl=document.getElementById('fnf-grid-'+type);
    if(!titleEl||!gridEl)return;
    titleEl.textContent=MN[st.vM]+' '+st.vY;
    var html=DN.map(function(d){return'<div class="fnf-dow">'+d+'</div>';}).join('');
    var first=new Date(st.vY,st.vM,1).getDay();
    var days=new Date(st.vY,st.vM+1,0).getDate();
    var prevDays=new Date(st.vY,st.vM,0).getDate();
    for(var i=0;i<first;i++){
      var pd=new Date(st.vY,st.vM-1,prevDays-first+1+i);
      html+=dayHtml(pd,true,st);
    }
    for(var d=1;d<=days;d++)html+=dayHtml(new Date(st.vY,st.vM,d),false,st);
    var rem=(7-((first+days)%7))%7;
    for(var r=1;r<=rem;r++)html+=dayHtml(new Date(st.vY,st.vM+1,r),true,st);
    gridEl.innerHTML=html;
    // wire day clicks
    gridEl.querySelectorAll('.fnf-day').forEach(function(el){
      el.addEventListener('click',function(){pickDay(type,parseInt(this.dataset.ts));});
    });
  }

  function dayHtml(d,other,st){
    var c='fnf-day';
    if(other)c+=' fnf-other';
    if(sameD(d,todayD))c+=' fnf-today';
    var isS=sameD(d,st.sFrom),isE=sameD(d,st.sTo);
    if(isS)c+=' fnf-sel-s';
    if(isE)c+=' fnf-sel-e';
    if(!isS&&!isE&&btw(d,st.sFrom,st.sTo))c+=' fnf-range';
    return'<div class="'+c+'" data-ts="'+d.getTime()+'">'+d.getDate()+'</div>';
  }

  function pickDay(type,ts){
    var st=getState(type);
    var d=new Date(ts);
    var body=document.getElementById('fnf-body-'+type);
    if(!body)return;
    var fromBtn=body.querySelector('.fnf-from-btn');
    var toBtn=body.querySelector('.fnf-to-btn');
    var hintEl=document.getElementById('fnf-hint-'+type);
    if(st.picking==='from'){
      st.sFrom=d;st.sTo=null;
      st.picking='to';
      if(fromBtn)fromBtn.classList.remove('fnf-active');
      if(toBtn)toBtn.classList.add('fnf-active');
      if(hintEl)hintEl.textContent='Tap an end date';
    } else {
      if(st.sFrom&&d<st.sFrom){st.sFrom=d;st.sTo=null;if(hintEl)hintEl.textContent='Tap an end date';}
      else{
        st.sTo=d;st.picking=null;
        if(toBtn)toBtn.classList.remove('fnf-active');
        var calPanel=document.getElementById('fnf-cal-'+type);
        if(calPanel)setTimeout(function(){calPanel.style.display='none';},160);
      }
    }
    updateDisp(type);
    // sync hidden inputs
    var fromInp=document.querySelector('.lf-from[data-type="'+type+'"]');
    var toInp=document.querySelector('.lf-to[data-type="'+type+'"]');
    if(fromInp)fromInp.value=toYMD(st.sFrom);
    if(toInp)toInp.value=toYMD(st.sTo);
    renderCal(type);
  }

  function updateDisp(type){
    var st=getState(type);
    var body=document.getElementById('fnf-body-'+type);
    if(!body)return;
    var fd=body.querySelector('.fnf-from-disp'),td=body.querySelector('.fnf-to-disp');
    if(fd){fd.textContent=fmtDisp(st.sFrom);fd.classList.toggle('fnf-ph',!st.sFrom);}
    if(td){td.textContent=fmtDisp(st.sTo);td.classList.toggle('fnf-ph',!st.sTo);}
  }

  function openCal(type,which){
    var st=getState(type);
    st.picking=which;
    var body=document.getElementById('fnf-body-'+type);
    if(!body)return;
    var fromBtn=body.querySelector('.fnf-from-btn');
    var toBtn=body.querySelector('.fnf-to-btn');
    if(fromBtn)fromBtn.classList.toggle('fnf-active',which==='from');
    if(toBtn)toBtn.classList.toggle('fnf-active',which==='to');
    var calPanel=document.getElementById('fnf-cal-'+type);
    if(calPanel)calPanel.style.display='block';
    var hintEl=document.getElementById('fnf-hint-'+type);
    if(hintEl)hintEl.textContent=which==='from'?'Tap a start date':'Tap an end date';
    renderCal(type);
  }

  function initPicker(type){
    var wrap=document.getElementById('lf-'+type);
    if(!wrap)return;

    // Custom chip
    var customChip=wrap.querySelector('.custom-chip[data-type="'+type+'"]');
    if(customChip){
      customChip.addEventListener('click',function(){
        // deactivate all preset chips
        wrap.querySelectorAll('.fnf-chip.df-btn').forEach(function(c){c.classList.remove('active');});
        customChip.classList.add('active');
        var body=document.getElementById('fnf-body-'+type);
        if(body)body.style.display='flex';
        var st=getState(type);
        st.sFrom=null;st.sTo=null;
        updateDisp(type);
        // sync hidden inputs
        var fromInp=document.querySelector('.lf-from[data-type="'+type+'"]');
        var toInp=document.querySelector('.lf-to[data-type="'+type+'"]');
        if(fromInp)fromInp.value='';
        if(toInp)toInp.value='';
        openCal(type,'from');
      });
    }

    // Preset chips — hide custom body
    wrap.querySelectorAll('.fnf-chip.df-btn[data-range]').forEach(function(btn){
      btn.addEventListener('click',function(){
        var body=document.getElementById('fnf-body-'+type);
        if(body)body.style.display='none';
        var calPanel=document.getElementById('fnf-cal-'+type);
        if(calPanel)calPanel.style.display='none';
        if(customChip)customChip.classList.remove('active');
        var st=getState(type);st.sFrom=null;st.sTo=null;
      });
    });

    // From/To buttons
    var body=document.getElementById('fnf-body-'+type);
    if(body){
      var fromBtn=body.querySelector('.fnf-from-btn');
      var toBtn=body.querySelector('.fnf-to-btn');
      if(fromBtn)fromBtn.addEventListener('click',function(){openCal(type,'from');});
      if(toBtn)toBtn.addEventListener('click',function(){openCal(type,'to');});
    }

    // Cal nav
    var calPanel=document.getElementById('fnf-cal-'+type);
    if(calPanel){
      calPanel.querySelectorAll('.fnf-cal-nav').forEach(function(nav){
        nav.addEventListener('click',function(){
          var st=getState(type);
          st.vM+=parseInt(this.dataset.dir);
          if(st.vM<0){st.vM=11;st.vY--;}
          if(st.vM>11){st.vM=0;st.vY++;}
          renderCal(type);
        });
      });
    }

    // Clear button resets state
    var clearBtn=wrap.querySelector('.lf-clear[data-type="'+type+'"]');
    if(clearBtn){
      clearBtn.addEventListener('click',function(){
        var st=getState(type);st.sFrom=null;st.sTo=null;
        updateDisp(type);
        var fromInp=document.querySelector('.lf-from[data-type="'+type+'"]');
        var toInp=document.querySelector('.lf-to[data-type="'+type+'"]');
        if(fromInp)fromInp.value='';
        if(toInp)toInp.value='';
        openCal(type,'from');
      });
    }

    // Apply — sync hidden inputs then trigger existing logic
    var applyBtn=wrap.querySelector('.lf-apply[data-type="'+type+'"]');
    if(applyBtn){
      applyBtn.addEventListener('click',function(){
        var st=getState(type);
        var fromInp=document.querySelector('.lf-from[data-type="'+type+'"]');
        var toInp=document.querySelector('.lf-to[data-type="'+type+'"]');
        if(fromInp)fromInp.value=toYMD(st.sFrom);
        if(toInp)toInp.value=toYMD(st.sTo);
        var calPanel=document.getElementById('fnf-cal-'+type);
        if(calPanel)calPanel.style.display='none';
      });
    }

    // Init calendar
    renderCal(type);
  }

  document.addEventListener('DOMContentLoaded',function(){
    ['income','expense','transfer','credit','savings'].forEach(initPicker);
  });
  // Also init after a delay in case auth renders late
  setTimeout(function(){
    ['income','expense','transfer','credit','savings'].forEach(function(t){
      if(!_state[t])initPicker(t);
    });
  },1200);
})();
