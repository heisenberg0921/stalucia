/* ═══════════════════════════════════════════════════════════════════════
   Fintra — Quick capture engine
   Additive. Reuses core: S, nxtId, normalizeDate, today, curYM, findAcc,
   fmt, save, toast, renderDash/Accounts/Log, stat*, goPanel, closeBnSheet.
   Nothing in app.core.js is modified.
   ═══════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  var PRESET_KEY  = 'fintra_qa_presets';
  var LASTACC_KEY = 'fintra_qa_acc';
  var EXP_CATS = ['Food','Transport','Utilities','Health','Shopping','Entertainment','Rent','Education','Subscription','Other'];
  var INC_CATS = ['Salary','Freelance','Business','Investment','Bonus','Other'];

  function $(id){ return document.getElementById(id); }
  function fnt(name){ return typeof window[name] === 'function' ? window[name] : null; }
  function peso(n){
    var f = fnt('fmt'); if (f) return f(Number(n) || 0);
    return '₱' + (Number(n) || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function esc(s){
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c];
    });
  }

  /* ── presets ──────────────────────────────────────────────────────── */
  function defaultPresets(){
    return [
      { id:'p_food',   emoji:'🍚', label:'Food',       type:'expense', category:'Food' },
      { id:'p_trans',  emoji:'🚍', label:'Transport',  type:'expense', category:'Transport' },
      { id:'p_coffee', emoji:'☕', label:'Coffee',     type:'expense', category:'Food' },
      { id:'p_load',   emoji:'📱', label:'Load',       type:'expense', category:'Utilities' },
      { id:'p_groc',   emoji:'🛒', label:'Groceries',  type:'expense', category:'Shopping' },
      { id:'p_inc',    emoji:'💵', label:'Income',     type:'income',  category:'Salary' }
    ];
  }
  function getPresets(){
    try { var r = localStorage.getItem(PRESET_KEY); if (r) return JSON.parse(r); } catch (e) {}
    var d = defaultPresets(); savePresets(d); return d;
  }
  function savePresets(p){ try { localStorage.setItem(PRESET_KEY, JSON.stringify(p)); } catch (e) {} }

  /* ── accounts ─────────────────────────────────────────────────────── */
  /* Quick Log posts income/expense entries. Those entry types never drive a
     credit-card balance (CCs are driven by usedCredit via the credit log, and
     recalcAllBalances skips CCs when replaying income/expense), so CC accounts
     are excluded here — same rule as the full form's account dropdowns. */
  function activeAccounts(){
    var S = window.S || {};
    return (S.accounts || []).filter(function (a) { return !a.archived && !a.isCC; });
  }
  function defaultAccountId(){
    var accs = activeAccounts(); if (!accs.length) return null;
    var stored = null; try { stored = localStorage.getItem(LASTACC_KEY); } catch (e) {}
    if (stored) { var f = fnt('findAcc'); var a = f ? f(stored) : null; if (a && !a.archived && !a.isCC) return a.id; }
    return accs[0].id;
  }
  function accName(id){ var f = fnt('findAcc'); var a = f ? f(id) : null; return a ? a.name : 'Account'; }

  /* ── commit a transaction through the core pipeline ───────────────── */
  /* BUG 1 FIX (Quick Log ledger/balance disagreement):
     Previously this pushed the ledger entry but NEVER applied the account
     balance effect — income/expense appeared in the list while the account
     stayed unchanged (and a later "Recalculate balances" would then shift
     balances unexpectedly). commit() now applies the same effect as the
     full form (saveEntry) and the recalc replay, EXACTLY ONCE:
       income  → account.balance += amt
       expense → account.balance -= amt
       CC accounts are never touched by income/expense (they are driven by
       usedCredit via the credit log — same rule as recalcAllBalances). */
  function commit(entry){
    var S = window.S; if (!S) return false;
    // Centralized money policy (FinanceCore) with a strict local fallback.
    var amt;
    if (window.FinanceCore && window.FinanceCore.parseAmount) {
      var p = window.FinanceCore.parseAmount(entry.amt);
      if (!p.ok) { var tfe = fnt('toast'); if (tfe) tfe(p.error, 'error'); return false; }
      amt = p.value;
    } else {
      amt = parseFloat(entry.amt);
      if (isNaN(amt) || !isFinite(amt) || amt <= 0 || amt > 1e12) return false;
      amt = +amt.toFixed(2);
    }
    // Resolve the account NOW against authoritative state — a stale id from
    // localStorage (deleted/archived account) must not create an orphan effect.
    var acc = null;
    if (entry.account) {
      var fA = fnt('findAcc');
      acc = fA ? fA(entry.account) : null;
      if (!acc || acc.archived || acc.isCC) {
        // Fall back to a valid liquid account instead of silently mis-posting.
        var fallbackId = defaultAccountId();
        acc = (fallbackId && fA) ? fA(fallbackId) : null;
        entry.account = acc ? acc.id : null;
      }
    }
    var id = fnt('nxtId') ? window.nxtId() : String(Date.now());
    var nd = fnt('normalizeDate'); var t0 = fnt('today') ? window.today() : (function(d){var m=d.getMonth()+1,dd=d.getDate();return d.getFullYear()+'-'+(m<10?'0':'')+m+'-'+(dd<10?'0':'')+dd;})(new Date());
    var dt = nd ? nd(t0) : t0;
    if (entry.type === 'income') {
      if (!S.income) S.income = [];
      S.income.push({ id:id, date:dt, source:entry.desc || entry.category || 'Income',
        category:entry.category || 'Other', account:entry.account || null, amt:amt, note:entry.note || '' });
    } else {
      if (!S.expense) S.expense = [];
      S.expense.push({ id:id, date:dt, desc:entry.desc || entry.category || 'Expense',
        category:entry.category || 'Other', account:entry.account || null, note:entry.note || '', amt:amt });
    }
    // Apply the balance effect exactly once (never for CC accounts).
    if (acc && !acc.isCC) {
      if (window.FinanceCore && window.FinanceCore.applyBalanceEffect) {
        window.FinanceCore.applyBalanceEffect(acc, entry.type === 'income' ? 'income' : 'expense', amt);
      } else {
        acc.balance = +((acc.balance || 0) + (entry.type === 'income' ? amt : -amt)).toFixed(2);
      }
    }
    if (entry.account) { try { localStorage.setItem(LASTACC_KEY, String(entry.account)); } catch (e) {} }
    var f;
    if (f = fnt('save'))            { try { f(); } catch (e) {} }
    if (f = fnt('renderLog'))       { try { f(entry.type); } catch (e) {} }
    if (f = fnt(entry.type === 'income' ? 'statIncome' : 'statExpense')) { try { f(); } catch (e) {} }
    if (f = fnt('updateProfileStats')) { try { f(); } catch (e) {} }
    if (f = fnt('renderAccounts'))  { try { f(); } catch (e) {} }
    if (f = fnt('renderDash'))      { try { f(); } catch (e) {} }
    return true;
  }

  /* ── chooser overlay (account / category / new-preset) ────────────── */
  function ensureChooser(){
    if ($('qa-chooser-overlay')) return;
    var ov = document.createElement('div'); ov.id = 'qa-chooser-overlay';
    ov.innerHTML = '<div class="qa-chooser" id="qa-chooser"></div>';
    ov.addEventListener('click', function (e) { if (e.target === ov) closeChooser(); });
    document.body.appendChild(ov);
  }
  function showChooser(){
    var ov = $('qa-chooser-overlay'); ov.style.display = 'flex';
    requestAnimationFrame(function(){ requestAnimationFrame(function(){ ov.classList.add('show'); }); });
  }
  function closeChooser(){
    var ov = $('qa-chooser-overlay'); if (!ov) return;
    ov.classList.remove('show'); setTimeout(function(){ ov.style.display = 'none'; }, 300);
  }
  function openChooserList(title, options, currentVal, onPick){
    ensureChooser(); var box = $('qa-chooser');
    var h = '<div class="qa-chooser-title">' + esc(title) + '</div>';
    options.forEach(function (o) {
      h += '<button type="button" class="qa-chooser-opt' + (String(o.value) === String(currentVal) ? ' sel' : '') +
           '" data-v="' + esc(String(o.value)) + '">' + esc(o.label) +
           (o.sub ? '<span class="qa-co-sub">' + esc(o.sub) + '</span>' : '') + '</button>';
    });
    box.innerHTML = h;
    box.querySelectorAll('.qa-chooser-opt').forEach(function (btn) {
      btn.addEventListener('click', function () { var v = this.getAttribute('data-v'); closeChooser(); onPick(v); });
    });
    showChooser();
  }
  function openNewPreset(){
    ensureChooser(); var box = $('qa-chooser');
    box.innerHTML =
      '<div class="qa-chooser-title">New quick-log preset</div>' +
      '<input class="qa-chooser-field" id="qanp-emoji" placeholder="Emoji (e.g. 🍔)" maxlength="4">' +
      '<input class="qa-chooser-field" id="qanp-label" placeholder="Label (e.g. Lunch)" maxlength="20">' +
      '<select class="qa-chooser-field" id="qanp-type"><option value="expense">Expense</option><option value="income">Income</option></select>' +
      '<select class="qa-chooser-field" id="qanp-cat"></select>' +
      '<button class="qa-pad-save" id="qanp-save" type="button">Add preset</button>';
    function fillCats(){
      var cats = $('qanp-type').value === 'income' ? INC_CATS : EXP_CATS;
      $('qanp-cat').innerHTML = cats.map(function (c) { return '<option>' + c + '</option>'; }).join('');
    }
    fillCats();
    $('qanp-type').addEventListener('change', fillCats);
    $('qanp-save').addEventListener('click', function () {
      var label = ($('qanp-label').value || '').trim(); if (!label) return;
      var ps = getPresets();
      ps.push({ id:'p_' + Date.now(), emoji:(($('qanp-emoji').value || '').trim() || '•'),
        label:label, type:$('qanp-type').value, category:$('qanp-cat').value });
      savePresets(ps); closeChooser(); renderPresets();
    });
    showChooser();
  }

  /* ── number-pad sheet ─────────────────────────────────────────────── */
  var pad = { type:'expense', amt:'', category:'Food', account:null, desc:'', presetId:null };

  function ensurePad(){
    if ($('qa-pad')) return;
    var ov = document.createElement('div'); ov.id = 'qa-pad-overlay';
    ov.addEventListener('click', closePad);
    document.body.appendChild(ov);

    var pd = document.createElement('div'); pd.id = 'qa-pad';
    pd.innerHTML =
      '<div class="qa-pad-handle"></div>' +
      '<div class="qa-pad-typetabs">' +
        '<button type="button" class="qa-pad-tab expense" data-t="expense">Expense</button>' +
        '<button type="button" class="qa-pad-tab income" data-t="income">Income</button>' +
      '</div>' +
      '<div class="qa-pad-amount zero" id="qa-amt"><span class="qa-cur">₱</span><span id="qa-amt-num">0</span></div>' +
      '<div class="qa-pad-desc-line" id="qa-desc-line"></div>' +
      '<div class="qa-pad-meta">' +
        '<button type="button" class="qa-chip" id="qa-acc-chip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg><span class="qa-chip-lbl" id="qa-acc-lbl">Account</span></button>' +
        '<button type="button" class="qa-chip" id="qa-cat-chip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg><span class="qa-chip-lbl" id="qa-cat-lbl">Category</span></button>' +
      '</div>' +
      '<div class="qa-keys" id="qa-keys"></div>' +
      '<button class="qa-pad-save" id="qa-save" type="button">Save</button>';
    document.body.appendChild(pd);

    var keys = ['1','2','3','4','5','6','7','8','9','.','0','back'];
    var kc = $('qa-keys');
    keys.forEach(function (k) {
      var b = document.createElement('button'); b.type = 'button';
      b.className = 'qa-key' + (k === 'back' ? ' qa-back' : '');
      b.innerHTML = k === 'back' ? '⌫' : k;
      b.addEventListener('click', function () { press(k); });
      kc.appendChild(b);
    });
    pd.querySelectorAll('.qa-pad-tab').forEach(function (t) {
      t.addEventListener('click', function () {
        var nt = this.getAttribute('data-t');
        if (nt === pad.type) return;
        // Manual switch = a custom entry now. Drop the tapped preset's label so an
        // income never inherits "Food" (or vice-versa) from the preset it opened from.
        pad.presetId = null;
        pad.desc = '';
        pad.category = (nt === 'income' ? INC_CATS[0] : EXP_CATS[0]);
        setType(nt);
        updateMeta();
      });
    });
    $('qa-acc-chip').addEventListener('click', function () {
      var opts = activeAccounts().map(function (a) {
        return { value:a.id, label:a.name, sub: a.isCC ? 'Credit' : peso(a.balance) };
      });
      if (!opts.length) { var tf = fnt('toast'); if (tf) tf('Add an account first.', 'error'); return; }
      openChooserList('Pay from', opts, pad.account, function (v) {
        pad.account = v; try { localStorage.setItem(LASTACC_KEY, String(v)); } catch (e) {} updateMeta();
      });
    });
    $('qa-cat-chip').addEventListener('click', function () {
      var cats = (pad.type === 'income' ? INC_CATS : EXP_CATS).map(function (c) { return { value:c, label:c }; });
      openChooserList('Category', cats, pad.category, function (v) { pad.category = v; updateMeta(); });
    });
    $('qa-save').addEventListener('click', savePad);
  }

  function setType(t){
    pad.type = t;
    document.querySelectorAll('.qa-pad-tab').forEach(function (x) {
      x.classList.toggle('active', x.getAttribute('data-t') === t);
    });
    var cats = t === 'income' ? INC_CATS : EXP_CATS;
    if (cats.indexOf(pad.category) < 0) pad.category = cats[0];
    var sb = $('qa-save'); if (sb) sb.textContent = t === 'income' ? 'Save income' : 'Save expense';
    updateMeta();
  }
  function press(k){
    if (k === 'back') { pad.amt = pad.amt.slice(0, -1); }
    else if (k === '.') { if (pad.amt.indexOf('.') < 0) pad.amt = (pad.amt || '0') + '.'; }
    else {
      if (pad.amt.indexOf('.') >= 0 && pad.amt.split('.')[1].length >= 2) return;
      if (pad.amt === '0') pad.amt = k; else pad.amt += k;
      if (pad.amt.replace('.', '').length > 12) pad.amt = pad.amt.slice(0, -1);
    }
    updateAmt();
  }
  function fmtAmtStr(s){
    if (!s) return '0';
    var parts = s.split('.'); var ip = (parts[0] || '0').replace(/^0+(?=\d)/, '');
    var withCommas = ip.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return withCommas + (parts.length > 1 ? '.' + parts[1] : '');
  }
  function updateAmt(){
    $('qa-amt-num').textContent = fmtAmtStr(pad.amt);
    var ok = parseFloat(pad.amt) > 0;
    $('qa-amt').classList.toggle('zero', !ok);
    $('qa-save').disabled = !ok;
  }
  function updateMeta(){
    $('qa-acc-lbl').textContent = pad.account ? accName(pad.account) : 'Account';
    $('qa-cat-lbl').textContent = pad.category || 'Category';
    $('qa-desc-line').textContent = pad.desc || '';
  }
  function openPad(type, preset){
    ensurePad();
    _padSaving = false; // re-arm save guard for the new session
    pad.presetId = preset ? preset.id : null;
    pad.desc     = preset ? preset.label : '';
    pad.account  = defaultAccountId();
    pad.amt      = (preset && preset.lastAmt) ? String(preset.lastAmt) : '';
    pad.category = preset ? preset.category : ((type === 'income') ? INC_CATS[0] : EXP_CATS[0]);
    setType(type || 'expense');
    updateAmt(); updateMeta();
    var ov = $('qa-pad-overlay'), pd = $('qa-pad');
    ov.style.display = 'block'; pd.style.display = 'block';
    requestAnimationFrame(function(){ requestAnimationFrame(function(){ ov.classList.add('show'); pd.classList.add('open'); }); });
  }
  function closePad(){
    var ov = $('qa-pad-overlay'), pd = $('qa-pad'); if (!pd) return;
    pd.classList.remove('open'); ov.classList.remove('show');
    setTimeout(function(){ ov.style.display = 'none'; pd.style.display = 'none'; }, 340);
  }
  var _padSaving = false; // FAMILY D FIX: double-tap during the 340ms close animation created duplicate entries
  function savePad(){
    if (_padSaving) return;
    var amt = parseFloat(pad.amt); if (!(amt > 0)) return;
    if (!pad.account) pad.account = defaultAccountId();
    if (!pad.account) { var tfA = fnt('toast'); if (tfA) tfA('Add an account first.', 'error'); return; }
    _padSaving = true;
    if (!commit({ type:pad.type, amt:amt, category:pad.category, desc:pad.desc, account:pad.account, note:'' })) {
      _padSaving = false;
      var tf0 = fnt('toast'); if (tf0) tf0('Could not save right now.', 'error'); return;
    }
    if (pad.presetId) {
      var ps = getPresets();
      for (var i = 0; i < ps.length; i++) { if (ps[i].id === pad.presetId) { ps[i].lastAmt = amt; break; } }
      savePresets(ps); renderPresets();
    }
    var tf = fnt('toast'); if (tf) tf((pad.type === 'income' ? 'Income' : 'Expense') + ' saved ✓', 'success');
    closePad();
    var cb = fnt('closeBnSheet'); if (cb) cb();
  }

  /* ── presets row inside the + sheet ───────────────────────────────── */
  function renderPresets(){
    var sheet = $('bn-sheet'); if (!sheet) return;
    var wrap = $('qa-presets-wrap');
    if (!wrap) {
      wrap = document.createElement('div'); wrap.id = 'qa-presets-wrap'; wrap.className = 'qa-presets-wrap';
      wrap.innerHTML =
        '<div class="qa-presets-head"><span class="qa-ph-title">Quick log</span>' +
        '<button class="qa-ph-edit" type="button">Edit</button></div>' +
        '<div class="qa-presets" id="qa-presets"></div>';
      var title = sheet.querySelector('.bn-sheet-title');
      var grid  = sheet.querySelector('.bn-sheet-grid-3');
      if (title) sheet.insertBefore(wrap, title.nextSibling);
      else if (grid) sheet.insertBefore(wrap, grid);
      else sheet.appendChild(wrap);
      wrap.querySelector('.qa-ph-edit').addEventListener('click', function () {
        wrap.classList.toggle('editing');
        this.textContent = wrap.classList.contains('editing') ? 'Done' : 'Edit';
      });
    }
    var row = $('qa-presets'); row.innerHTML = '';
    getPresets().forEach(function (p) {
      var b = document.createElement('button'); b.type = 'button';
      b.className = 'qa-preset' + (p.type === 'income' ? ' income' : '');
      b.innerHTML = '<span class="qa-emoji">' + esc(p.emoji || '•') + '</span>' +
        '<span class="qa-lbl">' + esc(p.label) + '</span>' +
        (p.lastAmt ? '<span class="qa-amt">' + peso(p.lastAmt) + '</span>' : '');
      var del = document.createElement('span'); del.className = 'qa-del'; del.textContent = '×';
      del.addEventListener('click', function (ev) {
        ev.stopPropagation();
        savePresets(getPresets().filter(function (x) { return x.id !== p.id; }));
        renderPresets();
      });
      b.appendChild(del);
      b.addEventListener('click', function () {
        if (wrap.classList.contains('editing')) return;
        openPad(p.type, p);
      });
      row.appendChild(b);
    });
    var add = document.createElement('button'); add.type = 'button'; add.className = 'qa-preset qa-add';
    add.innerHTML = '<span class="qa-emoji">＋</span><span class="qa-lbl">New</span>';
    add.addEventListener('click', openNewPreset);
    row.appendChild(add);
  }

  /* ── Safe to spend ────────────────────────────────────────────────── */
  function computeSTS(){
    var S = window.S || {};
    var accs   = (S.accounts || []).filter(function (a) { return !a.archived; });
    var liquid = accs.filter(function (a) { return !a.isCC; }).reduce(function (s, a) { return s + (a.balance || 0); }, 0);
    var t = fnt('today') ? window.today() : new Date().toISOString().slice(0, 10);
    var unpaid   = (S.bills || []).filter(function (b) { return !b.isPaid && !b.ended && b.dueDate; });
    var overdue  = unpaid.filter(function (b) { return b.dueDate < t; });
    var billsDue = unpaid.reduce(function (s, b) { return s + (b.amt || 0); }, 0);
    var safe = liquid - billsDue;
    var now = new Date();
    var dim = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    var daysLeft = Math.max(1, dim - now.getDate() + 1);
    // A daily allowance only means something over a real horizon. In the last few
    // days of the month it divides by 1–3 and explodes into a misleading figure,
    // so suppress it rather than tell someone to spend their whole balance today.
    var showPerDay = daysLeft >= 4 && safe > 0;
    return {
      safe: safe, perDay: showPerDay ? safe / daysLeft : 0, showPerDay: showPerDay,
      daysLeft: daysLeft, billsDue: billsDue,
      unpaidCount: unpaid.length, overdueCount: overdue.length,
      hasAccounts: accs.length > 0
    };
  }
  function injectSTS(){
    // 2026: disabled. The dashboard hero card now shows "Safe to Spend"
    // directly (see index.html #panel-dashboard .d-hero), so this
    // separately-injected duplicate card — including the "/day · Xd left"
    // runway line — is removed rather than rendered twice.
    var existing = $('qa-sts-card');
    if (existing && existing.parentNode) existing.parentNode.removeChild(existing);
    return;
    /* eslint-disable no-unreachable */
    var host = $('panel-dashboard'); if (!host) return;
    var card = $('qa-sts-card');
    if (!card) {
      card = document.createElement('div'); card.id = 'qa-sts-card';
      card.addEventListener('click', function () { var g = fnt('goPanel'); if (g) g('bills'); });
      var anchor = $('dash-alerts-wrap');
      if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(card, anchor);
      else host.insertBefore(card, host.firstChild);
    }
    var d = computeSTS();
    if (!d.hasAccounts) { card.style.display = 'none'; return; }
    card.style.display = '';
    var neg = d.safe < 0;
    var sub;
    if (neg) {
      sub = 'Bills exceed your cash by <b>' + peso(-d.safe) + '</b>';
    } else if (d.unpaidCount > 0) {
      sub = 'After <b>' + d.unpaidCount + '</b> unpaid bill' + (d.unpaidCount > 1 ? 's' : '') + ' (' + peso(d.billsDue) + ')';
      if (d.overdueCount > 0) sub += ' · <span class="qa-sts-od">' + d.overdueCount + ' overdue</span>';
    } else {
      sub = 'Across your cash accounts';
    }
    var perday = d.showPerDay
      ? '<div class="qa-sts-perday"><div class="pd-val">' + peso(d.perDay) + '</div><div class="pd-lbl">/day · ' + d.daysLeft + 'd left</div></div>'
      : '';
    card.innerHTML = perday +
      '<div class="qa-sts-lbl">Safe to spend</div>' +
      '<div class="qa-sts-val' + (neg ? ' neg' : '') + '">' + peso(d.safe) + '</div>' +
      '<div class="qa-sts-sub">' + sub + '</div>';
  }

  /* ── home-screen shortcut deep-links ──────────────────────────────── */
  function handleDeepLink(){
    try {
      var qa = new URLSearchParams(location.search).get('qa'); if (!qa) return;
      if (qa === 'expense' || qa === 'income') { openPad(qa, null); }
      else if (qa === 'today') {
        var S = window.S || {}; var t = fnt('today') ? window.today() : (function(d){var m=d.getMonth()+1,dd=d.getDate();return d.getFullYear()+'-'+(m<10?'0':'')+m+'-'+(dd<10?'0':'')+dd;})(new Date());
        var sum = (S.expense || []).filter(function (e) { return e.date === t; }).reduce(function (s, e) { return s + e.amt; }, 0);
        var g = fnt('goPanel'); if (g) g('dashboard');
        var tf = fnt('toast'); if (tf) tf('Spent today: ' + peso(sum), 'info');
      }
      history.replaceState({}, document.title, location.pathname);
    } catch (e) {}
  }

  /* ── De-dupe the net-worth grid ───────────────────────────────────── */
  /* The 2×2 stats grid repeats "Cash Flow", which already has its own richer
     card (with bars) right below. Drop that quadrant and let the 3 real stats
     sit in one tidy row. Inline !important wins over the stylesheet cleanly. */
  function tidyDashboard(){
    var grid = document.querySelector('#panel-dashboard .d-hero-stats');
    if (!grid) return;
    var items = grid.querySelectorAll('.d-hs-item');
    if (items[3]) items[3].style.setProperty('display', 'none', 'important');
    grid.style.setProperty('grid-template-columns', 'repeat(3,1fr)', 'important');
  }

  /* ── init ─────────────────────────────────────────────────────────── */
  function init(){
    try { renderPresets(); } catch (e) {}
    try { injectSTS(); } catch (e) {}
    try { tidyDashboard(); } catch (e) {}
    if (typeof window.renderDash === 'function' && !window.renderDash._qaWrapped) {
      var _rd = window.renderDash;
      window.renderDash = function () {
        var r = _rd.apply(this, arguments);
        try { injectSTS(); } catch (e) {}
        try { tidyDashboard(); } catch (e) {}
        return r;
      };
      window.renderDash._qaWrapped = true;
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
  window.addEventListener('load', function () { setTimeout(handleDeepLink, 700); });

  window.fintraQuickAdd = openPad;   // exposed for shortcuts / debugging
})();
