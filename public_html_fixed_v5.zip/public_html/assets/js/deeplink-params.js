
(function(){
  if (!window.location.search) return;

  // --- Parse params (with aliases) -------------------------------------
  var sp;
  try { sp = new URLSearchParams(window.location.search); } catch(e){ return; }
  function pick(){
    for (var i=0; i<arguments.length; i++){
      var v = sp.get(arguments[i]);
      if (v !== null && v !== '') return v;
    }
    return null;
  }
  var P = {
    log:     pick('log','type'),
    amount:  pick('amount','amt'),
    note:    pick('note','desc','description'),
    account: pick('account','acc','from'),
    to:      pick('to','dest','toAccount'),
    cat:     pick('cat','category'),
    view:    pick('view','panel','goto')
  };
  if (!P.log && !P.view) return;

  // --- Wait until the app is ready -------------------------------------
  var tries = 0;
  function ready(){
    return (typeof window.logForm === 'function') && window.S;
  }
  function waitForReady(cb){
    if (ready()) { cb(); return; }
    if (++tries > 80) return;        // ~8s max — give up silently
    setTimeout(function(){ waitForReady(cb); }, 100);
  }

  // --- Helpers ----------------------------------------------------------
  function findAccountByQuery(q){
    if (!q || !window.S || !window.S.accounts) return null;
    var qq = String(q).toLowerCase().trim();
    var pool = window.S.accounts.filter(function(a){ return a && !a.archived; });
    // 1) exact id
    for (var i=0; i<pool.length; i++){
      if (String(pool[i].id) === q) return pool[i];
    }
    // 2) exact name (case-insensitive)
    for (var j=0; j<pool.length; j++){
      if ((pool[j].name||'').toLowerCase() === qq) return pool[j];
    }
    // 3) substring on name
    for (var k=0; k<pool.length; k++){
      if ((pool[k].name||'').toLowerCase().indexOf(qq) !== -1) return pool[k];
    }
    return null;
  }

  function selectCategoryByText(q){
    if (!q) return false;
    var qq = String(q).toLowerCase().trim();
    var chips = document.querySelectorAll('#csh-cats .csh-cat');
    for (var i=0; i<chips.length; i++){
      var txt = (chips[i].textContent || '').toLowerCase();
      if (txt.indexOf(qq) !== -1) { chips[i].click(); return true; }
    }
    return false;
  }

  // --- Apply once app is ready -----------------------------------------
  function apply(){
    // Strip the query string so a refresh doesn't re-trigger the action.
    try {
      history.replaceState(null, '', location.pathname + location.hash);
    } catch(e){}

    // Panel navigation only — done.
    if (P.view && !P.log){
      if (typeof window.goPanel === 'function'){
        try { window.goPanel(String(P.view).toLowerCase()); } catch(e){}
      }
      return;
    }

    // Log a transaction.
    var type = String(P.log || 'expense').toLowerCase();
    var ok = ['expense','income','transfer','credit','savings'];
    if (ok.indexOf(type) === -1) type = 'expense';

    try { window.logForm(type); } catch(e){ return; }

    // Savings has its own UI flow; just open it and stop.
    if (type === 'savings') return;

    // Pre-fill fields. logForm → openSheet → switchType runs renderCats &
    // fillSheetSelects synchronously, so chips and the account select
    // already exist. A small delay lets the open animation breathe.
    setTimeout(function(){
      // Amount
      if (P.amount){
        var n = parseFloat(String(P.amount).replace(/[^\d.\-]/g,''));
        if (!isNaN(n) && n > 0){
          var ai = document.getElementById('csh-amount-val');
          if (ai){
            ai.value = n;
            try { ai.dispatchEvent(new Event('input', {bubbles:true})); } catch(e){}
          }
        }
      }

      // Note / description
      if (P.note){
        var ni = document.getElementById('csh-note');
        if (ni) ni.value = P.note;
      }

      // From account
      if (P.account){
        var fromAcc = findAccountByQuery(P.account);
        if (fromAcc){
          var sel = document.getElementById('csh-acc-from');
          if (sel) sel.value = fromAcc.id;
        }
      }

      // Destination account (transfers only)
      if (P.to && type === 'transfer'){
        var toAcc = findAccountByQuery(P.to);
        if (toAcc){
          var sel2 = document.getElementById('csh-acc-to');
          if (sel2) sel2.value = toAcc.id;
        }
      }

      // Category
      if (P.cat) selectCategoryByText(P.cat);

      // Toast confirmation so the user knows the deep link worked
      if (typeof window.toast === 'function'){
        try { window.toast('Pre-filled from shortcut', 'success'); } catch(e){}
      }
    }, 180);
  }

  if (document.readyState === 'complete'){
    waitForReady(apply);
  } else {
    window.addEventListener('load', function(){ waitForReady(apply); });
  }
})();
