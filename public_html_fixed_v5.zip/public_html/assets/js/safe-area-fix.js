
(function () {
  // ROOT CAUSE OF iOS PWA BUG:
  // nav.offsetHeight does NOT reliably include env(safe-area-inset-bottom)
  // when read via JS on iOS PWA (position:fixed + env() is compositor-level,
  // not always reflected in layout offsetHeight). This caused the JS to set
  // a padding-bottom that was too small by ~34px (the home-indicator height),
  // overriding the correct CSS value via inline !important.
  //
  // In Safari browser (non-PWA) env(safe-area-inset-bottom) = 0, so the
  // mismatch was 0 and it appeared to work fine.
  //
  // FIX: On mobile (<901px), CSS already has the correct value via
  //   var(--content-pb) = calc(88px + env(safe-area-inset-bottom, 0px) + 8px)
  // env() is ALWAYS correctly resolved in CSS, even on iOS PWA.
  // So on mobile we REMOVE any inline override and let CSS win.
  // JS only controls desktop where the bottom nav is hidden.

  function syncNavPadding() {
    var nav     = document.getElementById('bottom-nav');
    var content = document.querySelector('.content');
    if (!content) return;

    var isMobile = window.innerWidth < 901;

    if (isMobile) {
      // Remove any inline override — CSS var(--content-pb) handles this correctly
      // including the safe-area-inset-bottom via env() which CSS resolves reliably.
      content.style.removeProperty('padding-bottom');
      return;
    }

    // Desktop: no bottom nav visible — apply a small fixed padding
    content.style.setProperty('padding-bottom', '28px', 'important');
  }

  // 1. As early as possible after DOM is ready
  document.addEventListener('DOMContentLoaded', function () {
    requestAnimationFrame(function () {
      syncNavPadding();
      setTimeout(syncNavPadding, 500);
      setTimeout(syncNavPadding, 1500);
    });
  });

  // 2. On resize (rotation, soft-keyboard, browser chrome show/hide)
  window.addEventListener('resize', syncNavPadding, { passive: true });

  // 3. On every panel switch
  document.addEventListener('panel-shown', syncNavPadding);

  // 4. Expose for goPanel() hook
  window._syncNavPadding = syncNavPadding;
})();
