/* ════════════════════════════════════════════════════════════════════════
   FINTRA SERVICE WORKER  —  network-first

   The previous behaviour cached the app shell aggressively, so newly uploaded
   files wouldn't show up ("still the same" after a deploy). This version is
   NETWORK-FIRST: when online it always fetches the latest file from the server
   and only falls back to the cache when offline. It also takes control
   immediately (skipWaiting + clients.claim) and deletes old caches on every
   version bump, so an upload is reflected on the next load.

   ⚠️ When you deploy new files, bump CACHE_VERSION below (e.g. v4, v5…). That
   guarantees the old cache is purged and clients refresh.
   ════════════════════════════════════════════════════════════════════════ */

const CACHE_VERSION = 'fintra-v14-20260629b';
const CORE = ['./', './index.html'];

self.addEventListener('install', function (event) {
  // Activate this worker as soon as it's installed — don't wait for old tabs.
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_VERSION).then(function (cache) {
      return cache.addAll(CORE).catch(function () { /* best effort */ });
    })
  );
});

self.addEventListener('activate', function (event) {
  event.waitUntil((async function () {
    // Remove every cache that isn't the current version.
    const keys = await caches.keys();
    await Promise.all(keys.map(function (k) {
      if (k !== CACHE_VERSION) return caches.delete(k);
    }));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', function (event) {
  const req = event.request;
  if (req.method !== 'GET') return;

  event.respondWith((async function () {
    try {
      // NETWORK FIRST — always prefer the freshest file from the server.
      const fresh = await fetch(req);
      try {
        const url = new URL(req.url);
        if (fresh && fresh.status === 200 && url.origin === self.location.origin) {
          const cache = await caches.open(CACHE_VERSION);
          cache.put(req, fresh.clone());
        }
      } catch (e) { /* ignore cache write errors */ }
      return fresh;
    } catch (err) {
      // OFFLINE — fall back to whatever we cached last.
      const cached = await caches.match(req);
      if (cached) return cached;
      if (req.mode === 'navigate') {
        const idx = (await caches.match('./index.html')) || (await caches.match('./'));
        if (idx) return idx;
      }
      throw err;
    }
  })());
});

// Allow the page to tell a waiting worker to activate immediately.
self.addEventListener('message', function (event) {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});
